# WaveLog Brandmeister DMR Plugin

A hardware integration plugin for [WaveLog](https://github.com/wavelog/wavelog) that interfaces with the [Brandmeister](https://brandmeister.network) DMR network, enabling real-time monitoring of DMR activity and direct QSO logging from the WaveLog web interface.

## Features

- **Live Last Heard Monitor** — Real-time feed of DMR transmissions via Brandmeister's Socket.IO API
- **Flexible Subscriptions** — Monitor specific talkgroups, repeaters, or your personal hotspot
- **One-Click QSO Logging** — Log completed DMR sessions as QSOs with proper ADIF formatting (`MODE: DIGITALVOICE`, `SUBMODE: DMR`)
- **Auto-Log Mode** — Optionally auto-log qualifying sessions (configurable minimum duration threshold)
- **DMR ID Lookup** — Instant callsign/name/QTH resolution via RadioID.net
- **Hotspot Talkgroup Manager** — Add/remove static talkgroups on your Brandmeister hotspot
- **Session History** — Local cache of recent sessions with logged/unlogged status
- **Graceful Error Handling** — Connection failures, API timeouts, and missing config are all handled without crashing WaveLog

## Requirements

- **WaveLog** 2.x or 3.x (CodeIgniter 3 based)
- **PHP** 7.4+ with cURL extension enabled
- **MySQL** 5.7+ or **MariaDB** 10.3+
- A WaveLog user account with an API key (for QSO logging)
- A **Brandmeister account** (free) — only needed for hotspot talkgroup management
- Modern web browser with JavaScript enabled

## Installation

### Step 1: Copy Plugin Files

Copy the following files into your WaveLog installation directory, preserving the folder structure:

```
your-wavelog-installation/
├── application/
│   ├── controllers/
│   │   └── Brandmeister.php          ← Copy here
│   ├── models/
│   │   └── Brandmeister_model.php    ← Copy here
│   └── views/
│       └── brandmeister/
│           └── index.php             ← Copy here (create the brandmeister/ folder)
└── assets/
    ├── js/
    │   └── sections/
    │       └── brandmeister.js       ← Copy here
    └── sql/
        └── brandmeister_install.sql  ← Copy here (create the sql/ folder if needed)
```

### Step 2: Database Tables

The plugin will **automatically create** its database tables (`brandmeister_config` and `brandmeister_sessions`) the first time you access the plugin page.

Alternatively, you can manually run the SQL:

```bash
mysql -u your_user -p your_wavelog_db < assets/sql/brandmeister_install.sql
```

### Step 3: WaveLog API Key

The plugin logs QSOs through WaveLog's own API, so you need an API key:

1. Log into WaveLog
2. Go to your **Profile** → **API Keys**
3. Create a key with **Read & Write** permissions
4. The plugin uses this key automatically (no need to enter it anywhere)

### Step 4: Access the Plugin

Navigate to:

```
https://your-wavelog-url/index.php/brandmeister
```

You should see the Brandmeister DMR monitoring page with tabs for Live Monitor, QSO Candidates, Session History, Settings, and Hotspot Manager.

## Configuration

### Settings Tab

| Setting | Description |
|---------|-------------|
| **Your DMR ID** | Your 7-digit DMR radio ID (e.g., `2042076`) |
| **Hotspot/Repeater ID** | DMR ID of your hotspot or repeater to monitor |
| **Brandmeister API Key** | JWT from BM Dashboard → Profile → API Keys (only needed for managing static talkgroups) |
| **Station Profile** | WaveLog station profile to associate logged QSOs with |
| **Operating Frequency** | Your hotspot/repeater frequency in MHz (e.g., `438.800`) |
| **Band** | Operating band (70CM, 2M, 23CM, etc.) |
| **Default RST Sent/Rcvd** | Default signal reports for logged QSOs (typically `59`) |
| **Min QSO Duration** | Minimum transmission length in seconds to qualify as a QSO (filters kerchunks) |
| **Auto-log QSOs** | When enabled, qualifying sessions are logged automatically without confirmation |
| **Default Talkgroups** | Comma-separated TG IDs to auto-subscribe on connect (e.g., `91, 3100`) |
| **Default Repeaters** | Comma-separated repeater IDs to auto-subscribe on connect |

### Getting a Brandmeister API Key (Optional)

1. Go to [brandmeister.network](https://brandmeister.network) and log in
2. Click your profile → **Security Settings** → **API Keys**
3. Click **Add** to generate a new JWT token
4. Copy the token and paste it into the plugin's settings

> **Note:** The API key is only required for managing static talkgroups on your hotspot. All monitoring features work without it.

## Usage

### Live Monitoring

1. Click **Connect** to establish a connection to Brandmeister's Last Heard feed
2. Subscribe to talkgroups (e.g., TG 91 for Worldwide) or your hotspot ID
3. Watch real-time transmissions appear in the feed table
4. Active transmissions are highlighted in green

### Logging QSOs

**Manual Mode (default):**
1. When a transmission completes, it appears in the **QSO Candidates** tab
2. Click the ✓ **Log** button to log it as a QSO in WaveLog
3. Use **Log All** to batch-log all candidates

**Auto-Log Mode:**
1. Enable **Auto-log QSOs** in Settings
2. Set the **Min QSO Duration** threshold (e.g., 3 seconds)
3. Any qualifying session will be automatically logged

### Hotspot Manager

1. Configure your **Hotspot ID** and **Brandmeister API Key** in Settings
2. Go to the **Hotspot Manager** tab
3. Add or remove static talkgroups with the specified timeslot
4. Click **Refresh** to see current static talkgroup assignments

## Architecture

```
┌─────────────────────────────────────────────────────────────────────┐
│                        Operator's Browser                          │
│                                                                     │
│  ┌──────────────────┐    ┌─────────────────────────────────────┐   │
│  │  brandmeister.js │◄──►│  Brandmeister Socket.IO Server      │   │
│  │  (Socket.IO)     │    │  wss://api.brandmeister.network     │   │
│  └────────┬─────────┘    └─────────────────────────────────────┘   │
│           │ AJAX                                                    │
└───────────┼─────────────────────────────────────────────────────────┘
            │
            ▼
┌───────────────────────────────────┐     ┌─────────────────────────┐
│  WaveLog Server (PHP/CI3)         │     │  External APIs          │
│                                    │     │                         │
│  Brandmeister.php (Controller)    │────►│  BM REST API v2         │
│  Brandmeister_model.php (Model)   │────►│  RadioID.net            │
│  brandmeister/ views              │────►│  WaveLog /api/qso       │
│                                    │     │  (self — internal)      │
│  brandmeister_config (DB table)   │     └─────────────────────────┘
│  brandmeister_sessions (DB table) │
└───────────────────────────────────┘
```

**Key design decisions:**
- The Socket.IO connection runs **in the browser**, not on the PHP server — no long-running daemon needed
- The PHP backend acts as a **proxy and data store** for API calls, configuration, and QSO logging
- QSOs are logged via WaveLog's own `/api/qso` endpoint with ADIF format, ensuring all standard processing (DXCC lookup, award tracking, duplicate checking) applies

## ADIF Fields

QSOs are logged with the following ADIF fields:

| Field | Value |
|-------|-------|
| `MODE` | `DIGITALVOICE` |
| `SUBMODE` | `DMR` |
| `BAND` | Configured band (e.g., `70CM`) |
| `FREQ` | Configured frequency (e.g., `438.800`) |
| `RST_SENT` | Configured default (e.g., `59`) |
| `RST_RCVD` | Configured default (e.g., `59`) |
| `COMMENT` | `BrandMeister DMR TG <ID> <Name> (TS<Slot>)` |
| `NAME` | Remote operator name (from Brandmeister feed) |

## Troubleshooting

| Issue | Solution |
|-------|----------|
| Plugin page shows 404 | Ensure `Brandmeister.php` is in `application/controllers/` with the correct filename (capital B) |
| "No WaveLog API key found" | Create an API key in WaveLog Profile → API Keys with Read & Write permissions |
| Socket.IO won't connect | Check browser console for errors; ensure your network allows WebSocket connections to `api.brandmeister.network` |
| QSOs not logging | Verify a Station Profile is selected in Settings and your WaveLog API key has `readwrite` permissions |
| Hotspot manager fails | Ensure your Brandmeister API Key (JWT) is correctly entered in Settings |
| Tables not created | Navigate to `/index.php/brandmeister/install` to manually trigger table creation |

## License

MIT License — Free to use, modify, and distribute.

## Credits

- [WaveLog](https://github.com/wavelog/wavelog) — The awesome open-source amateur radio logging platform
- [Brandmeister](https://brandmeister.network) — The DMR network providing the Socket.IO and REST APIs
- [RadioID.net](https://radioid.net) — DMR ID database for callsign resolution
