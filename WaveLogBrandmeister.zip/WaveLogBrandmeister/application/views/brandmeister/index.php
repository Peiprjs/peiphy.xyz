<!--
============================================================================
WaveLog Brandmeister DMR Plugin — Main View
============================================================================
Renders the Brandmeister monitoring dashboard and configuration interface.
Uses Bootstrap 5 classes consistent with WaveLog's existing UI.

Sections:
  1. Connection Status Banner
  2. Live Last Heard Monitor
  3. QSO Candidate Queue
  4. Session History
  5. Settings Panel (collapsible)
  6. Hotspot Talkgroup Manager (collapsible)
============================================================================
-->

<?php
// ---- External Scripts (Socket.IO CDN) ----
// These are loaded before our plugin JS via script tags in the header.
if (!empty($external_scripts)) {
    foreach ($external_scripts as $script_url) {
        echo '<script src="' . htmlspecialchars($script_url) . '"></script>' . "\n";
    }
}
?>

<!-- ======================================================================
     HIDDEN CONFIG DATA (passed to JavaScript)
     ====================================================================== -->
<input type="hidden" id="bm_base_url" value="<?php echo base_url(); ?>">
<input type="hidden" id="bm_user_id" value="<?php echo $this->session->userdata('user_id'); ?>">

<?php if (!empty($bm_config)): ?>
<input type="hidden" id="bm_config_json" value="<?php echo htmlspecialchars(json_encode($bm_config)); ?>">
<?php endif; ?>

<div class="container-fluid" id="bm-plugin-container">

    <!-- ==================================================================
         CONNECTION STATUS BANNER
         ================================================================== -->
    <div class="row mb-3">
        <div class="col-12">
            <div id="bm-connection-status" class="alert alert-secondary d-flex align-items-center" role="alert">
                <span class="me-2" id="bm-status-icon">⬤</span>
                <span id="bm-status-text"><?php echo __("Disconnected from Brandmeister"); ?></span>
                <div class="ms-auto">
                    <button class="btn btn-sm btn-outline-success me-1" id="bm-connect-btn" onclick="BM.connect()">
                        <i class="fas fa-plug"></i> <?php echo __("Connect"); ?>
                    </button>
                    <button class="btn btn-sm btn-outline-danger d-none" id="bm-disconnect-btn" onclick="BM.disconnect()">
                        <i class="fas fa-times"></i> <?php echo __("Disconnect"); ?>
                    </button>
                    <span class="badge bg-info ms-2" id="bm-session-count">0 <?php echo __("sessions"); ?></span>
                </div>
            </div>
        </div>
    </div>

    <!-- ==================================================================
         MAIN CONTENT TABS
         ================================================================== -->
    <div class="row">
        <div class="col-12">
            <ul class="nav nav-tabs" id="bm-tabs" role="tablist">
                <li class="nav-item" role="presentation">
                    <button class="nav-link active" id="bm-tab-monitor" data-bs-toggle="tab"
                            data-bs-target="#bm-panel-monitor" type="button" role="tab">
                        <i class="fas fa-broadcast-tower"></i> <?php echo __("Live Monitor"); ?>
                    </button>
                </li>
                <li class="nav-item" role="presentation">
                    <button class="nav-link" id="bm-tab-candidates" data-bs-toggle="tab"
                            data-bs-target="#bm-panel-candidates" type="button" role="tab">
                        <i class="fas fa-clipboard-list"></i> <?php echo __("QSO Candidates"); ?>
                        <span class="badge bg-warning text-dark ms-1" id="bm-candidate-badge">0</span>
                    </button>
                </li>
                <li class="nav-item" role="presentation">
                    <button class="nav-link" id="bm-tab-history" data-bs-toggle="tab"
                            data-bs-target="#bm-panel-history" type="button" role="tab">
                        <i class="fas fa-history"></i> <?php echo __("Session History"); ?>
                    </button>
                </li>
                <li class="nav-item" role="presentation">
                    <button class="nav-link" id="bm-tab-settings" data-bs-toggle="tab"
                            data-bs-target="#bm-panel-settings" type="button" role="tab">
                        <i class="fas fa-cog"></i> <?php echo __("Settings"); ?>
                    </button>
                </li>
                <li class="nav-item" role="presentation">
                    <button class="nav-link" id="bm-tab-hotspot" data-bs-toggle="tab"
                            data-bs-target="#bm-panel-hotspot" type="button" role="tab">
                        <i class="fas fa-satellite-dish"></i> <?php echo __("Hotspot Manager"); ?>
                    </button>
                </li>
            </ul>
        </div>
    </div>

    <div class="tab-content mt-3" id="bm-tab-content">

        <!-- ==============================================================
             TAB 1: LIVE MONITOR
             ============================================================== -->
        <div class="tab-pane fade show active" id="bm-panel-monitor" role="tabpanel">

            <!-- Subscription Controls -->
            <div class="row mb-3">
                <div class="col-md-6">
                    <div class="input-group">
                        <span class="input-group-text"><?php echo __("Monitor TG"); ?></span>
                        <input type="text" class="form-control" id="bm-subscribe-tg"
                               placeholder="<?php echo __("Talkgroup ID (e.g. 91)"); ?>">
                        <button class="btn btn-outline-primary" onclick="BM.subscribeTG()">
                            <i class="fas fa-plus"></i> <?php echo __("Subscribe"); ?>
                        </button>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="input-group">
                        <span class="input-group-text"><?php echo __("Monitor RPT"); ?></span>
                        <input type="text" class="form-control" id="bm-subscribe-rpt"
                               placeholder="<?php echo __("Repeater/Hotspot ID"); ?>">
                        <button class="btn btn-outline-primary" onclick="BM.subscribeRPT()">
                            <i class="fas fa-plus"></i> <?php echo __("Subscribe"); ?>
                        </button>
                    </div>
                </div>
            </div>

            <!-- Active Subscriptions -->
            <div class="row mb-3">
                <div class="col-12">
                    <div id="bm-subscriptions" class="d-flex flex-wrap gap-2">
                        <!-- Subscription badges will be dynamically inserted here -->
                    </div>
                </div>
            </div>

            <!-- Live Last Heard Table -->
            <div class="row">
                <div class="col-12">
                    <div class="table-responsive">
                        <table class="table table-sm table-striped table-hover" id="bm-lastheard-table">
                            <thead class="table-dark">
                                <tr>
                                    <th style="width: 30px;"></th>
                                    <th><?php echo __("Callsign"); ?></th>
                                    <th><?php echo __("Name"); ?></th>
                                    <th><?php echo __("DMR ID"); ?></th>
                                    <th><?php echo __("Talkgroup"); ?></th>
                                    <th><?php echo __("TS"); ?></th>
                                    <th><?php echo __("Repeater"); ?></th>
                                    <th><?php echo __("Duration"); ?></th>
                                    <th><?php echo __("BER"); ?></th>
                                    <th><?php echo __("Loss"); ?></th>
                                    <th><?php echo __("Time"); ?></th>
                                    <th><?php echo __("Actions"); ?></th>
                                </tr>
                            </thead>
                            <tbody id="bm-lastheard-body">
                                <tr id="bm-lastheard-empty">
                                    <td colspan="12" class="text-center text-muted py-4">
                                        <i class="fas fa-satellite-dish fa-2x mb-2 d-block"></i>
                                        <?php echo __("Connect and subscribe to a talkgroup or repeater to see live activity."); ?>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                    <div class="d-flex justify-content-between align-items-center">
                        <small class="text-muted" id="bm-feed-stats">
                            <?php echo __("Events received:"); ?> <span id="bm-event-count">0</span>
                        </small>
                        <button class="btn btn-sm btn-outline-secondary" onclick="BM.clearFeed()">
                            <i class="fas fa-trash"></i> <?php echo __("Clear Feed"); ?>
                        </button>
                    </div>
                </div>
            </div>
        </div>

        <!-- ==============================================================
             TAB 2: QSO CANDIDATES
             ============================================================== -->
        <div class="tab-pane fade" id="bm-panel-candidates" role="tabpanel">
            <div class="row mb-3">
                <div class="col-12 d-flex justify-content-between align-items-center">
                    <h5 class="mb-0"><?php echo __("Completed Sessions Ready to Log"); ?></h5>
                    <div>
                        <button class="btn btn-sm btn-success me-1" onclick="BM.logAllCandidates()">
                            <i class="fas fa-check-double"></i> <?php echo __("Log All"); ?>
                        </button>
                        <button class="btn btn-sm btn-outline-danger" onclick="BM.clearCandidates()">
                            <i class="fas fa-trash"></i> <?php echo __("Clear All"); ?>
                        </button>
                    </div>
                </div>
            </div>
            <div class="table-responsive">
                <table class="table table-sm table-striped" id="bm-candidates-table">
                    <thead class="table-dark">
                        <tr>
                            <th><?php echo __("Callsign"); ?></th>
                            <th><?php echo __("Name"); ?></th>
                            <th><?php echo __("Talkgroup"); ?></th>
                            <th><?php echo __("TS"); ?></th>
                            <th><?php echo __("Duration"); ?></th>
                            <th><?php echo __("Date/Time"); ?></th>
                            <th><?php echo __("Actions"); ?></th>
                        </tr>
                    </thead>
                    <tbody id="bm-candidates-body">
                        <tr id="bm-candidates-empty">
                            <td colspan="7" class="text-center text-muted py-4">
                                <?php echo __("No QSO candidates yet. Sessions will appear here when transmissions complete."); ?>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>

        <!-- ==============================================================
             TAB 3: SESSION HISTORY
             ============================================================== -->
        <div class="tab-pane fade" id="bm-panel-history" role="tabpanel">
            <div class="row mb-3">
                <div class="col-12 d-flex justify-content-between align-items-center">
                    <h5 class="mb-0"><?php echo __("Recent Session History"); ?></h5>
                    <button class="btn btn-sm btn-outline-primary" onclick="BM.loadHistory()">
                        <i class="fas fa-sync"></i> <?php echo __("Refresh"); ?>
                    </button>
                </div>
            </div>
            <div class="table-responsive">
                <table class="table table-sm table-striped" id="bm-history-table">
                    <thead class="table-dark">
                        <tr>
                            <th><?php echo __("Callsign"); ?></th>
                            <th><?php echo __("Name"); ?></th>
                            <th><?php echo __("Talkgroup"); ?></th>
                            <th><?php echo __("TS"); ?></th>
                            <th><?php echo __("Duration"); ?></th>
                            <th><?php echo __("BER"); ?></th>
                            <th><?php echo __("Date/Time"); ?></th>
                            <th><?php echo __("Logged"); ?></th>
                        </tr>
                    </thead>
                    <tbody id="bm-history-body">
                        <tr>
                            <td colspan="8" class="text-center text-muted py-4">
                                <?php echo __("Click Refresh to load session history."); ?>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>

        <!-- ==============================================================
             TAB 4: SETTINGS
             ============================================================== -->
        <div class="tab-pane fade" id="bm-panel-settings" role="tabpanel">
            <form id="bm-settings-form" onsubmit="BM.saveSettings(event); return false;">

                <div class="row mb-4">
                    <div class="col-12">
                        <h5><?php echo __("Brandmeister Account"); ?></h5>
                        <hr>
                    </div>
                </div>

                <!-- DMR ID & Hotspot -->
                <div class="row mb-3">
                    <div class="col-md-4">
                        <label for="bm-dmr-id" class="form-label"><?php echo __("Your DMR ID"); ?></label>
                        <input type="text" class="form-control" id="bm-dmr-id" name="dmr_id"
                               placeholder="e.g. 2042076"
                               value="<?php echo htmlspecialchars($bm_config->dmr_id ?? ''); ?>">
                        <div class="form-text"><?php echo __("Your 7-digit DMR radio ID."); ?></div>
                    </div>
                    <div class="col-md-4">
                        <label for="bm-hotspot-id" class="form-label"><?php echo __("Hotspot/Repeater ID"); ?></label>
                        <input type="text" class="form-control" id="bm-hotspot-id" name="hotspot_id"
                               placeholder="e.g. 2042076"
                               value="<?php echo htmlspecialchars($bm_config->hotspot_id ?? ''); ?>">
                        <div class="form-text"><?php echo __("DMR ID of your hotspot or repeater to monitor."); ?></div>
                    </div>
                    <div class="col-md-4">
                        <label for="bm-api-key" class="form-label"><?php echo __("Brandmeister API Key"); ?></label>
                        <div class="input-group">
                            <input type="password" class="form-control" id="bm-api-key" name="bm_api_key"
                                   placeholder="<?php echo __("JWT from BM Dashboard (optional)"); ?>"
                                   value="<?php echo htmlspecialchars($bm_config->bm_api_key ?? ''); ?>">
                            <button class="btn btn-outline-secondary" type="button"
                                    onclick="this.previousElementSibling.type = this.previousElementSibling.type === 'password' ? 'text' : 'password'">
                                <i class="fas fa-eye"></i>
                            </button>
                        </div>
                        <div class="form-text">
                            <?php echo __("Only needed for managing static talkgroups. Generate at"); ?>
                            <a href="https://brandmeister.network" target="_blank">brandmeister.network</a>
                            → Profile → API Keys.
                        </div>
                    </div>
                </div>

                <div class="row mb-4 mt-4">
                    <div class="col-12">
                        <h5><?php echo __("QSO Logging"); ?></h5>
                        <hr>
                    </div>
                </div>

                <!-- Station Profile & Frequency -->
                <div class="row mb-3">
                    <div class="col-md-4">
                        <label for="bm-station-profile" class="form-label"><?php echo __("Station Profile"); ?></label>
                        <select class="form-select" id="bm-station-profile" name="station_profile_id">
                            <option value=""><?php echo __("-- Select Station Profile --"); ?></option>
                            <?php if (!empty($station_profiles)): ?>
                                <?php foreach ($station_profiles as $sp): ?>
                                    <option value="<?php echo $sp->station_id; ?>"
                                        <?php echo (isset($bm_config->station_profile_id) && $bm_config->station_profile_id == $sp->station_id) ? 'selected' : ''; ?>>
                                        <?php echo htmlspecialchars($sp->station_profile_name ?? $sp->station_callsign ?? 'Station #' . $sp->station_id); ?>
                                        (<?php echo htmlspecialchars($sp->station_callsign ?? ''); ?>)
                                    </option>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </select>
                        <div class="form-text"><?php echo __("WaveLog station profile for logged QSOs."); ?></div>
                    </div>
                    <div class="col-md-4">
                        <label for="bm-frequency" class="form-label"><?php echo __("Operating Frequency (MHz)"); ?></label>
                        <input type="text" class="form-control" id="bm-frequency" name="frequency"
                               placeholder="438.800"
                               value="<?php echo htmlspecialchars($bm_config->frequency ?? '438.800'); ?>">
                        <div class="form-text"><?php echo __("Your hotspot or repeater frequency for ADIF."); ?></div>
                    </div>
                    <div class="col-md-4">
                        <label for="bm-band" class="form-label"><?php echo __("Band"); ?></label>
                        <select class="form-select" id="bm-band" name="band">
                            <?php
                            $bands = ['70CM', '2M', '23CM', '33CM', '13CM'];
                            $current_band = $bm_config->band ?? '70CM';
                            foreach ($bands as $b):
                            ?>
                                <option value="<?php echo $b; ?>" <?php echo ($b === $current_band) ? 'selected' : ''; ?>>
                                    <?php echo $b; ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                </div>

                <!-- Signal Reports & Duration -->
                <div class="row mb-3">
                    <div class="col-md-3">
                        <label for="bm-rst-sent" class="form-label"><?php echo __("Default RST Sent"); ?></label>
                        <input type="text" class="form-control" id="bm-rst-sent" name="default_rst_sent"
                               value="<?php echo htmlspecialchars($bm_config->default_rst_sent ?? '59'); ?>">
                    </div>
                    <div class="col-md-3">
                        <label for="bm-rst-rcvd" class="form-label"><?php echo __("Default RST Rcvd"); ?></label>
                        <input type="text" class="form-control" id="bm-rst-rcvd" name="default_rst_rcvd"
                               value="<?php echo htmlspecialchars($bm_config->default_rst_rcvd ?? '59'); ?>">
                    </div>
                    <div class="col-md-3">
                        <label for="bm-min-duration" class="form-label"><?php echo __("Min QSO Duration (sec)"); ?></label>
                        <input type="number" class="form-control" id="bm-min-duration" name="min_qso_duration"
                               min="1" max="300"
                               value="<?php echo htmlspecialchars($bm_config->min_qso_duration ?? '3'); ?>">
                        <div class="form-text"><?php echo __("Ignore transmissions shorter than this."); ?></div>
                    </div>
                    <div class="col-md-3">
                        <div class="form-check form-switch mt-4 pt-2">
                            <input class="form-check-input" type="checkbox" id="bm-auto-log" name="auto_log_enabled"
                                   <?php echo (!empty($bm_config->auto_log_enabled)) ? 'checked' : ''; ?>>
                            <label class="form-check-label" for="bm-auto-log">
                                <?php echo __("Auto-log QSOs"); ?>
                            </label>
                            <div class="form-text"><?php echo __("Automatically log qualifying sessions."); ?></div>
                        </div>
                    </div>
                </div>

                <div class="row mb-4 mt-4">
                    <div class="col-12">
                        <h5><?php echo __("Monitoring Defaults"); ?></h5>
                        <hr>
                    </div>
                </div>

                <!-- Monitored Talkgroups & Repeaters -->
                <div class="row mb-3">
                    <div class="col-md-6">
                        <label for="bm-default-tgs" class="form-label"><?php echo __("Default Talkgroups"); ?></label>
                        <input type="text" class="form-control" id="bm-default-tgs" name="monitored_talkgroups"
                               placeholder="91, 3100, 31012"
                               value="<?php echo htmlspecialchars(
                                   !empty($bm_config->monitored_talkgroups) ? implode(', ', $bm_config->monitored_talkgroups) : ''
                               ); ?>">
                        <div class="form-text"><?php echo __("Comma-separated TG IDs to auto-subscribe on connect."); ?></div>
                    </div>
                    <div class="col-md-6">
                        <label for="bm-default-rpts" class="form-label"><?php echo __("Default Repeaters"); ?></label>
                        <input type="text" class="form-control" id="bm-default-rpts" name="monitored_repeaters"
                               placeholder="<?php echo __("Repeater/Hotspot DMR IDs"); ?>"
                               value="<?php echo htmlspecialchars(
                                   !empty($bm_config->monitored_repeaters) ? implode(', ', $bm_config->monitored_repeaters) : ''
                               ); ?>">
                        <div class="form-text"><?php echo __("Comma-separated repeater IDs to auto-subscribe on connect."); ?></div>
                    </div>
                </div>

                <!-- Save Button -->
                <div class="row mt-4">
                    <div class="col-12">
                        <button type="submit" class="btn btn-primary" id="bm-save-btn">
                            <i class="fas fa-save"></i> <?php echo __("Save Settings"); ?>
                        </button>
                        <span class="ms-3 text-success d-none" id="bm-save-status">
                            <i class="fas fa-check-circle"></i> <?php echo __("Settings saved!"); ?>
                        </span>
                    </div>
                </div>
            </form>
        </div>

        <!-- ==============================================================
             TAB 5: HOTSPOT TALKGROUP MANAGER
             ============================================================== -->
        <div class="tab-pane fade" id="bm-panel-hotspot" role="tabpanel">
            <div class="row mb-3">
                <div class="col-12">
                    <div class="alert alert-info">
                        <i class="fas fa-info-circle"></i>
                        <?php echo __("Manage static talkgroups on your Brandmeister hotspot. Requires a configured Hotspot ID and API Key in Settings."); ?>
                    </div>
                </div>
            </div>

            <!-- Add Static Talkgroup Form -->
            <div class="row mb-3">
                <div class="col-md-4">
                    <div class="input-group">
                        <span class="input-group-text"><?php echo __("TG ID"); ?></span>
                        <input type="number" class="form-control" id="bm-add-tg-id" placeholder="91">
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="input-group">
                        <span class="input-group-text"><?php echo __("Slot"); ?></span>
                        <select class="form-select" id="bm-add-tg-slot">
                            <option value="1">TS1</option>
                            <option value="2" selected>TS2</option>
                        </select>
                    </div>
                </div>
                <div class="col-md-3">
                    <button class="btn btn-success w-100" onclick="BM.addStaticTG()">
                        <i class="fas fa-plus"></i> <?php echo __("Add Static TG"); ?>
                    </button>
                </div>
                <div class="col-md-2">
                    <button class="btn btn-outline-primary w-100" onclick="BM.refreshDeviceInfo()">
                        <i class="fas fa-sync"></i> <?php echo __("Refresh"); ?>
                    </button>
                </div>
            </div>

            <!-- Device Info & Current Static Talkgroups -->
            <div class="row">
                <div class="col-md-4">
                    <div class="card">
                        <div class="card-header">
                            <i class="fas fa-info-circle"></i> <?php echo __("Hotspot Info"); ?>
                        </div>
                        <div class="card-body" id="bm-device-info">
                            <p class="text-muted"><?php echo __("No hotspot info loaded."); ?></p>
                        </div>
                    </div>
                </div>
                <div class="col-md-8">
                    <div class="card">
                        <div class="card-header">
                            <i class="fas fa-list"></i> <?php echo __("Current Static Talkgroups"); ?>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-sm table-striped" id="bm-static-tg-table">
                                    <thead>
                                        <tr>
                                            <th><?php echo __("TG ID"); ?></th>
                                            <th><?php echo __("Name"); ?></th>
                                            <th><?php echo __("Slot"); ?></th>
                                            <th><?php echo __("Actions"); ?></th>
                                        </tr>
                                    </thead>
                                    <tbody id="bm-static-tg-body">
                                        <tr>
                                            <td colspan="4" class="text-center text-muted">
                                                <?php echo __("Click Refresh to load current static talkgroups."); ?>
                                            </td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </div><!-- /tab-content -->

</div><!-- /container -->

<!-- ==================================================================
     TOAST NOTIFICATION CONTAINER
     ================================================================== -->
<div class="position-fixed bottom-0 end-0 p-3" style="z-index: 1080;">
    <div id="bm-toast" class="toast align-items-center text-white bg-success border-0"
         role="alert" aria-live="assertive" aria-atomic="true">
        <div class="d-flex">
            <div class="toast-body" id="bm-toast-body">
                <!-- Toast message inserted dynamically -->
            </div>
            <button type="button" class="btn-close btn-close-white me-2 m-auto"
                    data-bs-dismiss="toast" aria-label="Close"></button>
        </div>
    </div>
</div>
