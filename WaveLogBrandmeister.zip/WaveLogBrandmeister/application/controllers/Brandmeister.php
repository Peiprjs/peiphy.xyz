<?php
/**
 * ============================================================================
 * WaveLog Brandmeister DMR Plugin — Controller
 * ============================================================================
 *
 * Main controller providing the web interface and AJAX endpoints for the
 * Brandmeister DMR integration plugin.
 *
 * Routes (all prefixed with /index.php/brandmeister/):
 *   GET  /                    → Main plugin page (monitoring + settings)
 *   GET  /install             → Create database tables (first-run setup)
 *   GET  /settings            → Retrieve current user configuration (JSON)
 *   POST /settings            → Save user configuration (JSON)
 *   GET  /talkgroups          → Search Brandmeister talkgroup directory (JSON)
 *   GET  /lookup_dmrid/:id    → Resolve a DMR ID via RadioID.net (JSON)
 *   GET  /device_info/:id     → Get Brandmeister device/hotspot info (JSON)
 *   POST /manage_talkgroup    → Add/remove static talkgroup on hotspot (JSON)
 *   POST /log_qso             → Log a Brandmeister session as a WaveLog QSO (JSON)
 *   POST /save_session        → Cache a session to the local database (JSON)
 *   GET  /sessions            → Retrieve recent session history (JSON)
 *   GET  /station_profiles    → List user's station profiles (JSON)
 *
 * @package     WaveLog
 * @subpackage  Brandmeister
 * @author      WaveLog Brandmeister Plugin
 * @license     MIT
 */

defined('BASEPATH') OR exit('No direct script access allowed');

class Brandmeister extends CI_Controller {

    /**
     * Constructor — loads required models and checks authentication.
     */
    public function __construct()
    {
        parent::__construct();

        // Load the Brandmeister model for all methods
        $this->load->model('brandmeister_model');
    }

    // =======================================================================
    //  MAIN PAGE
    // =======================================================================

    /**
     * Renders the main Brandmeister monitoring and settings page.
     *
     * URL: /index.php/brandmeister
     */
    public function index()
    {
        // Require authenticated user
        if ($this->user_model->validate_session() == 0) {
            redirect('user/login');
        }

        // Auto-install tables on first visit if they don't exist
        if (!$this->brandmeister_model->tables_exist()) {
            $this->brandmeister_model->install_tables();
        }

        session_write_close();

        // Page data
        $data['page_title'] = __("Brandmeister DMR");

        // Load optional WaveLog Worker support for WebSocket push
        $this->load->is_loaded('worker') ?: $this->load->library('worker');
        $data['worker_enabled'] = $this->worker->is_enabled();

        // Footer scripts — load Socket.IO client and our plugin JS
        $footerData = [];
        $footerData['scripts'] = [
            'assets/js/sections/brandmeister.js',
        ];

        // External scripts loaded via the view (Socket.IO CDN)
        $data['external_scripts'] = [
            'https://cdn.socket.io/4.7.5/socket.io.min.js',
        ];

        // Load the user's config to pre-populate the settings form
        $user_id = $this->session->userdata('user_id');
        $data['bm_config'] = $this->brandmeister_model->get_config($user_id);

        // Load station profiles for the dropdown
        $data['station_profiles'] = $this->brandmeister_model->get_station_profiles($user_id);

        // Render the page within WaveLog's standard layout
        $this->load->view('interface_assets/header', $data);
        $this->load->view('brandmeister/index', $data);
        $this->load->view('interface_assets/footer', $footerData);
    }

    // =======================================================================
    //  DATABASE INSTALLATION
    // =======================================================================

    /**
     * Creates the plugin's database tables.
     *
     * URL: /index.php/brandmeister/install
     * Typically called once during first-time setup, but is idempotent.
     */
    public function install()
    {
        if ($this->user_model->validate_session() == 0) {
            redirect('user/login');
        }

        $result = $this->brandmeister_model->install_tables();

        if ($this->input->is_ajax_request()) {
            $this->_json_response(['success' => $result, 'message' => 'Tables created successfully']);
        } else {
            $this->session->set_flashdata('success', 'Brandmeister plugin tables installed successfully.');
            redirect('brandmeister');
        }
    }

    // =======================================================================
    //  SETTINGS (GET / POST)
    // =======================================================================

    /**
     * Handles user configuration retrieval and saving.
     *
     * GET  /index.php/brandmeister/settings → Returns current config as JSON
     * POST /index.php/brandmeister/settings → Saves config and returns result
     */
    public function settings()
    {
        if ($this->user_model->validate_session() == 0) {
            $this->_json_response(['success' => false, 'error' => 'Unauthorized'], 401);
            return;
        }

        $user_id = $this->session->userdata('user_id');

        if ($this->input->method() === 'post') {
            // ---- SAVE SETTINGS ----
            $input = json_decode($this->input->raw_input_stream, true);

            if (!$input) {
                // Fallback to form-encoded POST data
                $input = $this->input->post();
            }

            if (empty($input)) {
                $this->_json_response(['success' => false, 'error' => 'No data received'], 400);
                return;
            }

            $result = $this->brandmeister_model->save_config($user_id, $input);

            $this->_json_response([
                'success' => $result,
                'message' => $result ? 'Settings saved successfully' : 'Failed to save settings',
            ]);

        } else {
            // ---- GET SETTINGS ----
            $config = $this->brandmeister_model->get_config($user_id);

            // Mask the API key for security (only show last 8 chars)
            if ($config && !empty($config->bm_api_key)) {
                $key = $config->bm_api_key;
                $config->bm_api_key_masked = str_repeat('•', max(0, strlen($key) - 8))
                                           . substr($key, -8);
                // Still send the full key so JS can use it for API calls
                // (it's already authenticated via session)
            }

            $this->_json_response([
                'success' => true,
                'data'    => $config,
            ]);
        }
    }

    // =======================================================================
    //  TALKGROUP DIRECTORY SEARCH
    // =======================================================================

    /**
     * Searches the Brandmeister talkgroup directory.
     *
     * URL: /index.php/brandmeister/talkgroups?search=worldwide
     *
     * @return void  Outputs JSON
     */
    public function talkgroups()
    {
        if ($this->user_model->validate_session() == 0) {
            $this->_json_response(['success' => false, 'error' => 'Unauthorized'], 401);
            return;
        }

        $search = $this->input->get('search');
        $result = $this->brandmeister_model->get_talkgroups($search);

        $this->_json_response($result);
    }

    // =======================================================================
    //  DMR ID LOOKUP (RadioID.net)
    // =======================================================================

    /**
     * Resolves a DMR ID to callsign, name, and QTH via RadioID.net.
     *
     * URL: /index.php/brandmeister/lookup_dmrid/2042076
     *
     * @param  int $dmr_id  7-digit DMR ID
     * @return void          Outputs JSON
     */
    public function lookup_dmrid($dmr_id = null)
    {
        if ($this->user_model->validate_session() == 0) {
            $this->_json_response(['success' => false, 'error' => 'Unauthorized'], 401);
            return;
        }

        if (!$dmr_id || !is_numeric($dmr_id)) {
            $this->_json_response(['success' => false, 'error' => 'Invalid DMR ID'], 400);
            return;
        }

        $result = $this->brandmeister_model->lookup_radioid((int)$dmr_id);
        $this->_json_response($result);
    }

    // =======================================================================
    //  DEVICE / HOTSPOT INFO
    // =======================================================================

    /**
     * Retrieves device/hotspot information from the Brandmeister API.
     *
     * URL: /index.php/brandmeister/device_info/2042076
     *
     * @param  string $device_id  DMR ID of the device
     * @return void               Outputs JSON
     */
    public function device_info($device_id = null)
    {
        if ($this->user_model->validate_session() == 0) {
            $this->_json_response(['success' => false, 'error' => 'Unauthorized'], 401);
            return;
        }

        if (!$device_id) {
            $this->_json_response(['success' => false, 'error' => 'Device ID required'], 400);
            return;
        }

        $result = $this->brandmeister_model->get_device_info($device_id);
        $this->_json_response($result);
    }

    // =======================================================================
    //  STATIC TALKGROUP MANAGEMENT
    // =======================================================================

    /**
     * Adds or removes a static talkgroup on the user's hotspot.
     *
     * URL: POST /index.php/brandmeister/manage_talkgroup
     *
     * Expected JSON payload:
     * {
     *   "action":       "add" | "remove",
     *   "talkgroup_id": 91,
     *   "slot":         2
     * }
     */
    public function manage_talkgroup()
    {
        if ($this->user_model->validate_session() == 0) {
            $this->_json_response(['success' => false, 'error' => 'Unauthorized'], 401);
            return;
        }

        $input = json_decode($this->input->raw_input_stream, true);
        if (!$input) {
            $this->_json_response(['success' => false, 'error' => 'Invalid JSON payload'], 400);
            return;
        }

        $user_id = $this->session->userdata('user_id');
        $config  = $this->brandmeister_model->get_config($user_id);

        // Validate prerequisites
        if (!$config || empty($config->hotspot_id)) {
            $this->_json_response([
                'success' => false,
                'error'   => 'No hotspot ID configured. Please set your hotspot ID in settings.',
            ], 400);
            return;
        }

        if (empty($config->bm_api_key)) {
            $this->_json_response([
                'success' => false,
                'error'   => 'No Brandmeister API key configured. An API key is required to manage talkgroups.',
            ], 400);
            return;
        }

        $action       = $input['action'] ?? '';
        $talkgroup_id = (int)($input['talkgroup_id'] ?? 0);
        $slot         = (int)($input['slot'] ?? 2);

        if (!$talkgroup_id || !in_array($slot, [1, 2])) {
            $this->_json_response(['success' => false, 'error' => 'Invalid talkgroup ID or slot'], 400);
            return;
        }

        // Execute the action
        if ($action === 'add') {
            $result = $this->brandmeister_model->add_static_talkgroup(
                $config->hotspot_id, $talkgroup_id, $slot, $config->bm_api_key
            );
        } elseif ($action === 'remove') {
            $result = $this->brandmeister_model->remove_static_talkgroup(
                $config->hotspot_id, $talkgroup_id, $slot, $config->bm_api_key
            );
        } else {
            $this->_json_response(['success' => false, 'error' => 'Invalid action. Use "add" or "remove".'], 400);
            return;
        }

        $this->_json_response($result);
    }

    // =======================================================================
    //  QSO LOGGING
    // =======================================================================

    /**
     * Logs a Brandmeister session as a QSO in WaveLog.
     *
     * URL: POST /index.php/brandmeister/log_qso
     *
     * Expected JSON payload: a Brandmeister session object with fields like
     * SourceCall, SourceID, DestinationID, Start, Stop, Duration, etc.
     */
    public function log_qso()
    {
        if ($this->user_model->validate_session() == 0) {
            $this->_json_response(['success' => false, 'error' => 'Unauthorized'], 401);
            return;
        }

        $session_data = json_decode($this->input->raw_input_stream, true);
        if (!$session_data) {
            $this->_json_response(['success' => false, 'error' => 'Invalid JSON payload'], 400);
            return;
        }

        $user_id = $this->session->userdata('user_id');
        $config  = $this->brandmeister_model->get_config($user_id);

        if (!$config) {
            $this->_json_response([
                'success' => false,
                'error'   => 'Brandmeister plugin not configured. Please save your settings first.',
            ], 400);
            return;
        }

        if (empty($config->station_profile_id)) {
            $this->_json_response([
                'success' => false,
                'error'   => 'No station profile selected. Please choose a station profile in settings.',
            ], 400);
            return;
        }

        // Validate that we have a callsign to log
        $call = $session_data['SourceCall'] ?? $session_data['source_call'] ?? '';
        if (empty($call) || $call === 'UNKNOWN') {
            $this->_json_response([
                'success' => false,
                'error'   => 'Cannot log QSO: remote station callsign is missing.',
            ], 400);
            return;
        }

        // Format the session as an ADIF record
        $adif = $this->brandmeister_model->format_adif_qso($session_data, $config);

        // Log via WaveLog's QSO API
        $result = $this->brandmeister_model->log_qso_to_wavelog($adif, $config->station_profile_id);

        // If we have a local session DB ID, mark it as logged
        if ($result['success'] && !empty($session_data['local_db_id'])) {
            $qso_id = $result['data']['qso_id'] ?? null;
            $this->brandmeister_model->mark_session_logged($session_data['local_db_id'], $qso_id);
        }

        $this->_json_response($result);
    }

    // =======================================================================
    //  SESSION HISTORY
    // =======================================================================

    /**
     * Saves a completed session to the local database cache.
     *
     * URL: POST /index.php/brandmeister/save_session
     */
    public function save_session()
    {
        if ($this->user_model->validate_session() == 0) {
            $this->_json_response(['success' => false, 'error' => 'Unauthorized'], 401);
            return;
        }

        $session_data = json_decode($this->input->raw_input_stream, true);
        if (!$session_data) {
            $this->_json_response(['success' => false, 'error' => 'Invalid JSON payload'], 400);
            return;
        }

        $user_id = $this->session->userdata('user_id');
        $db_id   = $this->brandmeister_model->save_session($user_id, $session_data);

        $this->_json_response([
            'success' => ($db_id !== FALSE),
            'id'      => $db_id,
        ]);
    }

    /**
     * Retrieves recent session history for the current user.
     *
     * URL: GET /index.php/brandmeister/sessions?limit=50
     */
    public function sessions()
    {
        if ($this->user_model->validate_session() == 0) {
            $this->_json_response(['success' => false, 'error' => 'Unauthorized'], 401);
            return;
        }

        $user_id = $this->session->userdata('user_id');
        $limit   = (int)($this->input->get('limit') ?: 50);
        $limit   = min($limit, 200); // Cap at 200

        $sessions = $this->brandmeister_model->get_sessions($user_id, $limit);

        $this->_json_response([
            'success' => true,
            'data'    => $sessions,
        ]);
    }

    // =======================================================================
    //  STATION PROFILES
    // =======================================================================

    /**
     * Returns the current user's WaveLog station profiles.
     *
     * URL: GET /index.php/brandmeister/station_profiles
     */
    public function station_profiles()
    {
        if ($this->user_model->validate_session() == 0) {
            $this->_json_response(['success' => false, 'error' => 'Unauthorized'], 401);
            return;
        }

        $user_id  = $this->session->userdata('user_id');
        $profiles = $this->brandmeister_model->get_station_profiles($user_id);

        $this->_json_response([
            'success' => true,
            'data'    => $profiles,
        ]);
    }

    // =======================================================================
    //  PRIVATE HELPERS
    // =======================================================================

    /**
     * Sends a JSON response with appropriate headers.
     *
     * @param  array $data       Response data to encode as JSON
     * @param  int   $http_code  HTTP status code (default: 200)
     * @return void
     */
    private function _json_response($data, $http_code = 200)
    {
        $this->output
            ->set_status_header($http_code)
            ->set_content_type('application/json')
            ->set_output(json_encode($data));
    }
}
