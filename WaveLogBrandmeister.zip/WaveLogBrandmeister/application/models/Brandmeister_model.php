<?php
/**
 * ============================================================================
 * WaveLog Brandmeister DMR Plugin — Model
 * ============================================================================
 *
 * Handles all database operations for the Brandmeister plugin and provides
 * helper methods for communicating with external APIs:
 *   - Brandmeister REST API v2  (talkgroups, device management)
 *   - RadioID.net               (DMR ID → callsign/QTH resolution)
 *   - WaveLog's own QSO API     (logging contacts via ADIF)
 *
 * @package     WaveLog
 * @subpackage  Brandmeister
 * @author      WaveLog Brandmeister Plugin
 * @license     MIT
 */

defined('BASEPATH') OR exit('No direct script access allowed');

class Brandmeister_model extends CI_Model {

    // -----------------------------------------------------------------------
    // External API base URLs
    // -----------------------------------------------------------------------

    /** @var string Brandmeister REST API v2 base URL */
    const BM_API_BASE = 'https://api.brandmeister.network/v2';

    /** @var string Brandmeister Socket.IO endpoint (for reference — used by JS) */
    const BM_SOCKET_URL = 'https://api.brandmeister.network';

    /** @var string RadioID.net DMR user database API */
    const RADIOID_API_BASE = 'https://database.radioid.net/api/dmr/user';

    /** @var int cURL timeout in seconds for external API requests */
    const API_TIMEOUT = 10;

    /** @var int Maximum number of sessions to retain per user in the cache */
    const MAX_SESSION_HISTORY = 500;

    // -----------------------------------------------------------------------
    // Constructor
    // -----------------------------------------------------------------------

    public function __construct()
    {
        parent::__construct();
        $this->load->database();
    }

    // =======================================================================
    //  DATABASE INSTALLATION
    // =======================================================================

    /**
     * Creates the plugin's database tables if they do not already exist.
     *
     * This method is called automatically by the controller's install()
     * endpoint and can also be triggered manually from the plugin settings UI.
     *
     * @return bool TRUE on success
     */
    public function install_tables()
    {
        // Load the SQL file and execute each statement
        $sql_path = FCPATH . 'assets/sql/brandmeister_install.sql';

        if (file_exists($sql_path)) {
            $sql = file_get_contents($sql_path);
            // Split on semicolons that are followed by a newline (avoids splitting inside strings)
            $statements = preg_split('/;\s*\n/', $sql);

            foreach ($statements as $stmt) {
                $stmt = trim($stmt);
                // Skip empty statements and comments
                if (!empty($stmt) && strpos($stmt, '--') !== 0) {
                    $this->db->query($stmt);
                }
            }
        }

        return TRUE;
    }

    /**
     * Checks whether the plugin tables exist in the database.
     *
     * @return bool TRUE if both tables exist
     */
    public function tables_exist()
    {
        return $this->db->table_exists('brandmeister_config')
            && $this->db->table_exists('brandmeister_sessions');
    }

    // =======================================================================
    //  CONFIGURATION CRUD
    // =======================================================================

    /**
     * Retrieves the Brandmeister configuration for a given user.
     *
     * @param  int        $user_id  WaveLog user ID
     * @return object|null          Config row object or NULL if not configured
     */
    public function get_config($user_id)
    {
        $query = $this->db->get_where('brandmeister_config', ['user_id' => (int)$user_id], 1);
        $row = $query->row();

        if ($row) {
            // Decode the obfuscated API key for use in the application
            if (!empty($row->bm_api_key)) {
                $row->bm_api_key = base64_decode($row->bm_api_key);
            }
            // Decode JSON arrays
            $row->monitored_talkgroups = json_decode($row->monitored_talkgroups, true) ?: [];
            $row->monitored_repeaters  = json_decode($row->monitored_repeaters, true) ?: [];
        }

        return $row;
    }

    /**
     * Saves (inserts or updates) the Brandmeister configuration for a user.
     *
     * @param  int   $user_id  WaveLog user ID
     * @param  array $data     Associative array of config fields to save
     * @return bool            TRUE on success
     */
    public function save_config($user_id, $data)
    {
        // Sanitise and prepare the data
        $clean = [
            'user_id'               => (int)$user_id,
            'bm_api_key'            => !empty($data['bm_api_key'])
                                        ? base64_encode(trim($data['bm_api_key']))
                                        : NULL,
            'dmr_id'                => !empty($data['dmr_id'])
                                        ? trim($data['dmr_id'])
                                        : NULL,
            'hotspot_id'            => !empty($data['hotspot_id'])
                                        ? trim($data['hotspot_id'])
                                        : NULL,
            'monitored_talkgroups'  => !empty($data['monitored_talkgroups'])
                                        ? json_encode(array_map('intval', (array)$data['monitored_talkgroups']))
                                        : '[]',
            'monitored_repeaters'   => !empty($data['monitored_repeaters'])
                                        ? json_encode(array_map('intval', (array)$data['monitored_repeaters']))
                                        : '[]',
            'station_profile_id'    => !empty($data['station_profile_id'])
                                        ? (int)$data['station_profile_id']
                                        : NULL,
            'auto_log_enabled'      => !empty($data['auto_log_enabled']) ? 1 : 0,
            'min_qso_duration'      => isset($data['min_qso_duration'])
                                        ? max(1, (int)$data['min_qso_duration'])
                                        : 3,
            'default_rst_sent'      => !empty($data['default_rst_sent'])
                                        ? trim($data['default_rst_sent'])
                                        : '59',
            'default_rst_rcvd'      => !empty($data['default_rst_rcvd'])
                                        ? trim($data['default_rst_rcvd'])
                                        : '59',
            'frequency'             => !empty($data['frequency'])
                                        ? trim($data['frequency'])
                                        : '438.800',
            'band'                  => !empty($data['band'])
                                        ? trim($data['band'])
                                        : '70CM',
        ];

        // Check if a config row already exists for this user
        $existing = $this->db->get_where('brandmeister_config', ['user_id' => (int)$user_id], 1);

        if ($existing->num_rows() > 0) {
            // Update existing row
            $this->db->where('user_id', (int)$user_id);
            return $this->db->update('brandmeister_config', $clean);
        } else {
            // Insert new row
            return $this->db->insert('brandmeister_config', $clean);
        }
    }

    // =======================================================================
    //  SESSION HISTORY CACHE
    // =======================================================================

    /**
     * Saves a completed Brandmeister session to the local cache.
     *
     * @param  int   $user_id  WaveLog user ID
     * @param  array $data     Session data from the Socket.IO event
     * @return int|false        Inserted row ID or FALSE on failure
     */
    public function save_session($user_id, $data)
    {
        $row = [
            'user_id'          => (int)$user_id,
            'session_id'       => $data['SessionID'] ?? null,
            'source_id'        => $data['SourceID'] ?? null,
            'source_call'      => $data['SourceCall'] ?? null,
            'source_name'      => $data['SourceName'] ?? null,
            'destination_id'   => $data['DestinationID'] ?? null,
            'destination_name' => $data['DestinationName'] ?? null,
            'slot'             => $data['Slot'] ?? null,
            'link_call'        => $data['LinkCall'] ?? null,
            'start_time'       => !empty($data['Start'])
                                    ? date('Y-m-d H:i:s', $data['Start'])
                                    : null,
            'stop_time'        => !empty($data['Stop'])
                                    ? date('Y-m-d H:i:s', $data['Stop'])
                                    : null,
            'duration'         => $data['Duration'] ?? null,
            'ber'              => $data['BER'] ?? null,
            'rssi'             => $data['RSSI'] ?? null,
            'loss'             => $data['Loss'] ?? null,
            'logged'           => 0,
        ];

        $result = $this->db->insert('brandmeister_sessions', $row);

        if ($result) {
            // Prune old sessions to keep the table manageable
            $this->_prune_sessions($user_id);
            return $this->db->insert_id();
        }

        return FALSE;
    }

    /**
     * Retrieves recent sessions from the cache for a given user.
     *
     * @param  int $user_id  WaveLog user ID
     * @param  int $limit    Maximum number of sessions to return
     * @return array          Array of session row objects
     */
    public function get_sessions($user_id, $limit = 50)
    {
        $this->db->where('user_id', (int)$user_id);
        $this->db->order_by('start_time', 'DESC');
        $this->db->limit((int)$limit);
        return $this->db->get('brandmeister_sessions')->result();
    }

    /**
     * Marks a session as logged and records the WaveLog QSO ID.
     *
     * @param  int $session_db_id   The local database ID of the session
     * @param  int $wavelog_qso_id  The WaveLog QSO record ID (if available)
     * @return bool
     */
    public function mark_session_logged($session_db_id, $wavelog_qso_id = null)
    {
        $this->db->where('id', (int)$session_db_id);
        return $this->db->update('brandmeister_sessions', [
            'logged'         => 1,
            'wavelog_qso_id' => $wavelog_qso_id,
        ]);
    }

    /**
     * Removes old sessions beyond the retention limit.
     *
     * @param  int $user_id  WaveLog user ID
     * @return void
     */
    private function _prune_sessions($user_id)
    {
        // Count current sessions for this user
        $this->db->where('user_id', (int)$user_id);
        $count = $this->db->count_all_results('brandmeister_sessions');

        if ($count > self::MAX_SESSION_HISTORY) {
            // Delete oldest sessions exceeding the limit
            $excess = $count - self::MAX_SESSION_HISTORY;
            $this->db->where('user_id', (int)$user_id);
            $this->db->order_by('start_time', 'ASC');
            $this->db->limit($excess);
            $old = $this->db->get('brandmeister_sessions')->result();

            foreach ($old as $row) {
                $this->db->delete('brandmeister_sessions', ['id' => $row->id]);
            }
        }
    }

    // =======================================================================
    //  BRANDMEISTER REST API v2 CLIENT
    // =======================================================================

    /**
     * Makes an HTTP request to the Brandmeister REST API v2.
     *
     * @param  string      $method   HTTP method (GET, POST, DELETE)
     * @param  string      $endpoint API endpoint path (e.g. '/talkgroup')
     * @param  array|null  $data     Request body data (for POST/PUT)
     * @param  string|null $api_key  JWT API key (required for write operations)
     * @return array                 ['success' => bool, 'data' => mixed, 'error' => string|null]
     */
    public function bm_api_request($method, $endpoint, $data = null, $api_key = null)
    {
        $url = self::BM_API_BASE . '/' . ltrim($endpoint, '/');

        $ch = curl_init();

        // Common cURL options
        curl_setopt_array($ch, [
            CURLOPT_URL            => $url,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT        => self::API_TIMEOUT,
            CURLOPT_CONNECTTIMEOUT => 5,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_USERAGENT      => 'WaveLog-Brandmeister-Plugin/1.0',
        ]);

        // Set up headers
        $headers = ['Accept: application/json'];

        if ($api_key) {
            $headers[] = 'Authorization: Bearer ' . $api_key;
        }

        // Configure method-specific options
        switch (strtoupper($method)) {
            case 'POST':
                curl_setopt($ch, CURLOPT_POST, true);
                if ($data) {
                    $json_body = json_encode($data);
                    curl_setopt($ch, CURLOPT_POSTFIELDS, $json_body);
                    $headers[] = 'Content-Type: application/json';
                    $headers[] = 'Content-Length: ' . strlen($json_body);
                }
                break;

            case 'DELETE':
                curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'DELETE');
                break;

            case 'PUT':
            case 'PATCH':
                curl_setopt($ch, CURLOPT_CUSTOMREQUEST, strtoupper($method));
                if ($data) {
                    $json_body = json_encode($data);
                    curl_setopt($ch, CURLOPT_POSTFIELDS, $json_body);
                    $headers[] = 'Content-Type: application/json';
                    $headers[] = 'Content-Length: ' . strlen($json_body);
                }
                break;

            // GET is the default
        }

        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

        // Execute the request
        $response = curl_exec($ch);
        $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $error = curl_error($ch);
        curl_close($ch);

        // Handle errors
        if ($error) {
            log_message('error', 'Brandmeister API cURL error: ' . $error);
            return [
                'success' => false,
                'data'    => null,
                'error'   => 'Connection error: ' . $error,
                'code'    => 0,
            ];
        }

        $decoded = json_decode($response, true);

        if ($http_code >= 200 && $http_code < 300) {
            return [
                'success' => true,
                'data'    => $decoded ?? $response,
                'error'   => null,
                'code'    => $http_code,
            ];
        }

        log_message('error', "Brandmeister API HTTP {$http_code}: {$response}");
        return [
            'success' => false,
            'data'    => $decoded,
            'error'   => "HTTP {$http_code}: " . ($decoded['message'] ?? $response),
            'code'    => $http_code,
        ];
    }

    // =======================================================================
    //  TALKGROUP DIRECTORY
    // =======================================================================

    /**
     * Fetches the Brandmeister talkgroup directory.
     *
     * Results are cached in the PHP session for 15 minutes to reduce API load.
     *
     * @param  string|null $search  Optional search term to filter talkgroups
     * @return array                ['success' => bool, 'data' => array]
     */
    public function get_talkgroups($search = null)
    {
        // Check session cache (15-minute TTL)
        $cache_key = 'bm_talkgroups';
        $cached = $this->session->userdata($cache_key);

        if ($cached && (time() - $cached['timestamp']) < 900) {
            $talkgroups = $cached['data'];
        } else {
            // Fetch from Brandmeister API
            $result = $this->bm_api_request('GET', 'talkgroup');

            if (!$result['success']) {
                return $result;
            }

            $talkgroups = $result['data'];

            // Cache in session
            $this->session->set_userdata($cache_key, [
                'data'      => $talkgroups,
                'timestamp' => time(),
            ]);
        }

        // Apply search filter if provided
        if ($search) {
            $search = strtolower($search);
            $talkgroups = array_filter($talkgroups, function($tg) use ($search) {
                return strpos(strtolower($tg['name'] ?? ''), $search) !== false
                    || strpos(strtolower($tg['description'] ?? ''), $search) !== false
                    || strpos((string)($tg['id'] ?? ''), $search) !== false;
            });
            $talkgroups = array_values($talkgroups); // Re-index
        }

        return [
            'success' => true,
            'data'    => $talkgroups,
            'error'   => null,
        ];
    }

    // =======================================================================
    //  DEVICE / HOTSPOT MANAGEMENT
    // =======================================================================

    /**
     * Retrieves device/hotspot information from the Brandmeister API.
     *
     * @param  string $device_id  DMR ID of the device/hotspot
     * @return array               API response
     */
    public function get_device_info($device_id)
    {
        return $this->bm_api_request('GET', 'device/' . urlencode($device_id));
    }

    /**
     * Adds a static talkgroup to a hotspot.
     *
     * @param  string $hotspot_id   DMR ID of the hotspot
     * @param  int    $talkgroup_id Talkgroup ID to add
     * @param  int    $slot         DMR timeslot (1 or 2)
     * @param  string $api_key      Brandmeister JWT API key
     * @return array                API response
     */
    public function add_static_talkgroup($hotspot_id, $talkgroup_id, $slot, $api_key)
    {
        return $this->bm_api_request('POST', 'device/' . urlencode($hotspot_id) . '/talkgroup', [
            'group' => (int)$talkgroup_id,
            'slot'  => (int)$slot,
        ], $api_key);
    }

    /**
     * Removes a static talkgroup from a hotspot.
     *
     * @param  string $hotspot_id   DMR ID of the hotspot
     * @param  int    $talkgroup_id Talkgroup ID to remove
     * @param  int    $slot         DMR timeslot (1 or 2)
     * @param  string $api_key      Brandmeister JWT API key
     * @return array                API response
     */
    public function remove_static_talkgroup($hotspot_id, $talkgroup_id, $slot, $api_key)
    {
        $endpoint = 'device/' . urlencode($hotspot_id) . '/talkgroup/'
                  . urlencode($slot) . '/' . urlencode($talkgroup_id);
        return $this->bm_api_request('DELETE', $endpoint, null, $api_key);
    }

    // =======================================================================
    //  RADIOID.NET DMR ID RESOLUTION
    // =======================================================================

    /**
     * Looks up a DMR ID on RadioID.net to resolve callsign, name, and QTH.
     *
     * Results are cached in the database session to avoid repeated lookups
     * during active monitoring.
     *
     * @param  int $dmr_id  7-digit DMR ID
     * @return array         ['success' => bool, 'data' => array|null]
     */
    public function lookup_radioid($dmr_id)
    {
        $dmr_id = (int)$dmr_id;

        // Check session cache first
        $cache_key = 'radioid_cache';
        $cache = $this->session->userdata($cache_key) ?: [];

        if (isset($cache[$dmr_id]) && (time() - $cache[$dmr_id]['ts']) < 3600) {
            return [
                'success' => true,
                'data'    => $cache[$dmr_id]['data'],
                'cached'  => true,
            ];
        }

        // Query RadioID.net
        $url = self::RADIOID_API_BASE . '/?id=' . $dmr_id;

        $ch = curl_init();
        curl_setopt_array($ch, [
            CURLOPT_URL            => $url,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT        => self::API_TIMEOUT,
            CURLOPT_CONNECTTIMEOUT => 5,
            CURLOPT_USERAGENT      => 'WaveLog-Brandmeister-Plugin/1.0 (contact: wavelog@example.com)',
        ]);

        $response = curl_exec($ch);
        $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $error = curl_error($ch);
        curl_close($ch);

        if ($error || $http_code !== 200) {
            log_message('error', "RadioID lookup failed for {$dmr_id}: HTTP {$http_code} - {$error}");
            return [
                'success' => false,
                'data'    => null,
                'error'   => 'RadioID lookup failed',
            ];
        }

        $decoded = json_decode($response, true);
        $user_data = null;

        if (!empty($decoded['results']) && count($decoded['results']) > 0) {
            $user_data = $decoded['results'][0];
        }

        // Cache the result (even if null, to prevent repeated failed lookups)
        $cache[$dmr_id] = ['data' => $user_data, 'ts' => time()];

        // Keep cache size manageable (max 200 entries)
        if (count($cache) > 200) {
            // Remove oldest entries
            uasort($cache, function($a, $b) { return $a['ts'] - $b['ts']; });
            $cache = array_slice($cache, -100, null, true);
        }

        $this->session->set_userdata($cache_key, $cache);

        return [
            'success' => ($user_data !== null),
            'data'    => $user_data,
            'cached'  => false,
        ];
    }

    // =======================================================================
    //  ADIF QSO FORMATTING & LOGGING
    // =======================================================================

    /**
     * Formats a Brandmeister session as an ADIF record string.
     *
     * @param  array  $session  Session data (from Socket.IO or database)
     * @param  object $config   User's brandmeister_config row
     * @return string            ADIF-formatted record ending with <EOR>
     */
    public function format_adif_qso($session, $config)
    {
        // Determine QSO date and time from the session start
        $start_ts = $session['Start'] ?? strtotime($session['start_time'] ?? 'now');
        $qso_date = gmdate('Ymd', $start_ts);
        $time_on  = gmdate('His', $start_ts);

        // Determine QSO end time
        $stop_ts = $session['Stop'] ?? strtotime($session['stop_time'] ?? 'now');
        $time_off = gmdate('His', $stop_ts);

        // Remote station callsign
        $call = strtoupper(trim($session['SourceCall'] ?? $session['source_call'] ?? 'UNKNOWN'));

        // Operating frequency and band
        $freq = $config->frequency ?? '438.800';
        $band = $config->band ?? '70CM';

        // Signal reports
        $rst_sent = $config->default_rst_sent ?? '59';
        $rst_rcvd = $config->default_rst_rcvd ?? '59';

        // Talkgroup info for the comment field
        $tg_id   = $session['DestinationID'] ?? $session['destination_id'] ?? '';
        $tg_name = $session['DestinationName'] ?? $session['destination_name'] ?? '';
        $slot    = $session['Slot'] ?? $session['slot'] ?? '';
        $comment = "BrandMeister DMR TG {$tg_id} {$tg_name} (TS{$slot})";

        // Remote station name for the NAME field
        $name = trim(
            ($session['SourceName'] ?? $session['source_name'] ?? '')
        );

        // Build the ADIF string
        $adif = '';
        $adif .= $this->_adif_field('CALL', $call);
        $adif .= $this->_adif_field('QSO_DATE', $qso_date);
        $adif .= $this->_adif_field('TIME_ON', $time_on);
        $adif .= $this->_adif_field('TIME_OFF', $time_off);
        $adif .= $this->_adif_field('BAND', $band);
        $adif .= $this->_adif_field('FREQ', $freq);
        $adif .= $this->_adif_field('MODE', 'DIGITALVOICE');
        $adif .= $this->_adif_field('SUBMODE', 'DMR');
        $adif .= $this->_adif_field('RST_SENT', $rst_sent);
        $adif .= $this->_adif_field('RST_RCVD', $rst_rcvd);
        $adif .= $this->_adif_field('COMMENT', $comment);

        if (!empty($name)) {
            $adif .= $this->_adif_field('NAME', $name);
        }

        $adif .= '<EOR>';

        return $adif;
    }

    /**
     * Logs a QSO to WaveLog using its own API endpoint.
     *
     * This method makes an internal HTTP request to WaveLog's /api/qso
     * endpoint, which handles duplicate checking and all standard QSO
     * processing (DXCC lookup, award tracking, etc.).
     *
     * @param  string $adif_string        ADIF-formatted QSO record
     * @param  int    $station_profile_id  WaveLog station profile ID
     * @return array                       ['success' => bool, 'message' => string]
     */
    public function log_qso_to_wavelog($adif_string, $station_profile_id)
    {
        // Get the user's WaveLog API key
        $this->load->model('user_model');
        $api_key = $this->_get_wavelog_api_key();

        if (!$api_key) {
            return [
                'success' => false,
                'message' => 'No WaveLog API key found. Please generate one in your WaveLog profile.',
            ];
        }

        // Build the API request payload
        $payload = json_encode([
            'key'                => $api_key,
            'station_profile_id' => (string)$station_profile_id,
            'type'               => 'adif',
            'string'             => $adif_string,
        ]);

        // Determine the WaveLog base URL
        $base_url = rtrim(base_url(), '/');
        $api_url  = $base_url . '/index.php/api/qso';

        // Make the internal API request
        $ch = curl_init();
        curl_setopt_array($ch, [
            CURLOPT_URL            => $api_url,
            CURLOPT_POST           => true,
            CURLOPT_POSTFIELDS     => $payload,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT        => 15,
            CURLOPT_HTTPHEADER     => [
                'Content-Type: application/json',
                'Content-Length: ' . strlen($payload),
            ],
            // Allow self-signed certs for local installations
            CURLOPT_SSL_VERIFYPEER => false,
            CURLOPT_SSL_VERIFYHOST => 0,
        ]);

        $response  = curl_exec($ch);
        $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $error     = curl_error($ch);
        curl_close($ch);

        if ($error) {
            log_message('error', 'WaveLog QSO API error: ' . $error);
            return [
                'success' => false,
                'message' => 'Failed to connect to WaveLog API: ' . $error,
            ];
        }

        $decoded = json_decode($response, true);

        if ($http_code >= 200 && $http_code < 300) {
            return [
                'success' => true,
                'message' => 'QSO logged successfully',
                'data'    => $decoded,
            ];
        }

        return [
            'success' => false,
            'message' => 'WaveLog API returned HTTP ' . $http_code . ': '
                       . ($decoded['message'] ?? $response),
        ];
    }

    // =======================================================================
    //  STATION PROFILES
    // =======================================================================

    /**
     * Retrieves the list of station profiles available to the current user.
     *
     * Used to populate the station profile selector in the settings UI.
     *
     * @param  int   $user_id  WaveLog user ID
     * @return array            Array of station profile rows
     */
    public function get_station_profiles($user_id)
    {
        // WaveLog stores station profiles in the 'station_profile' table
        // associated with user_id
        if ($this->db->table_exists('station_profile')) {
            $this->db->where('user_id', (int)$user_id);
            $this->db->or_where('user_id', null); // Shared/club stations
            $this->db->order_by('station_profile_name', 'ASC');
            return $this->db->get('station_profile')->result();
        }

        return [];
    }

    // =======================================================================
    //  PRIVATE HELPERS
    // =======================================================================

    /**
     * Formats a single ADIF field tag.
     *
     * @param  string $name   Field name (e.g. 'CALL', 'FREQ')
     * @param  string $value  Field value
     * @return string          ADIF field string, e.g. '<CALL:4>W1AW '
     */
    private function _adif_field($name, $value)
    {
        $value = (string)$value;
        $len   = strlen($value);
        return "<{$name}:{$len}>{$value} ";
    }

    /**
     * Retrieves the current user's WaveLog API key for internal API calls.
     *
     * @return string|null  API key string or NULL if none found
     */
    private function _get_wavelog_api_key()
    {
        $user_id = $this->session->userdata('user_id');

        if (!$user_id) {
            return null;
        }

        // Query the api_keys / api table for a read-write key belonging to this user
        // WaveLog uses different table names depending on version
        $table = $this->db->table_exists('api_keys') ? 'api_keys' : 'api';

        $this->db->where('user_id', (int)$user_id);
        $this->db->where('rights', 'readwrite');
        $this->db->limit(1);
        $query = $this->db->get($table);

        if ($query->num_rows() > 0) {
            return $query->row()->key;
        }

        // Fallback: try any key for this user
        $this->db->where('user_id', (int)$user_id);
        $this->db->limit(1);
        $query = $this->db->get($table);

        return ($query->num_rows() > 0) ? $query->row()->key : null;
    }
}
