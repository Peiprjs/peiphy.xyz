-- ============================================================================
-- WaveLog Brandmeister DMR Plugin — Database Schema
-- ============================================================================
-- Run this SQL against your WaveLog database (MySQL / MariaDB) to create the
-- tables required by the Brandmeister plugin.  The plugin's install() method
-- will also execute these statements automatically on first use.
-- ============================================================================

-- ---------------------------------------------------------------------------
-- brandmeister_config
-- Stores per-user Brandmeister integration settings.
-- Each WaveLog user may have exactly one configuration row.
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `brandmeister_config` (
  `id`                    INT           AUTO_INCREMENT PRIMARY KEY,
  `user_id`               INT           NOT NULL,

  -- Brandmeister REST API v2 JWT (only needed for write operations such as
  -- managing static talkgroups on a hotspot).  Stored as-is; the PHP model
  -- base64-encodes it before persisting for minimal obfuscation.
  `bm_api_key`            VARCHAR(1024) DEFAULT NULL,

  -- Operator's 7-digit DMR ID (e.g. 2042076)
  `dmr_id`                VARCHAR(16)   DEFAULT NULL,

  -- Hotspot / repeater DMR ID that the operator owns or monitors
  `hotspot_id`            VARCHAR(16)   DEFAULT NULL,

  -- JSON arrays of talkgroup IDs and repeater IDs to subscribe to
  -- via the Socket.IO Last Heard feed.  Example: [91, 3100, 31012]
  `monitored_talkgroups`  TEXT          DEFAULT NULL,
  `monitored_repeaters`   TEXT          DEFAULT NULL,

  -- WaveLog station_profile.station_id that logged QSOs will be associated with
  `station_profile_id`    INT           DEFAULT NULL,

  -- When enabled, completed sessions that exceed min_qso_duration are
  -- automatically logged as QSOs without operator confirmation.
  `auto_log_enabled`      TINYINT(1)    DEFAULT 0,

  -- Minimum transmission duration (seconds) for a session to qualify as
  -- a loggable QSO.  Filters out kerchunks and brief PTTs.
  `min_qso_duration`      INT           DEFAULT 3,

  -- Default signal reports applied to auto-logged DMR QSOs
  `default_rst_sent`      VARCHAR(8)    DEFAULT '59',
  `default_rst_rcvd`      VARCHAR(8)    DEFAULT '59',

  -- Default operating frequency in MHz written into the ADIF FREQ field.
  -- Operators should set this to their hotspot or repeater frequency.
  `frequency`             VARCHAR(16)   DEFAULT '438.800',

  -- Default band for ADIF — derived from frequency but can be overridden
  `band`                  VARCHAR(8)    DEFAULT '70CM',

  `created_at`            DATETIME      DEFAULT CURRENT_TIMESTAMP,
  `updated_at`            DATETIME      DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,

  -- Each user may have only one config row
  UNIQUE KEY `uk_user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- ---------------------------------------------------------------------------
-- brandmeister_sessions
-- Caches recent Brandmeister Last Heard sessions for the dashboard widget
-- and provides an audit trail of logged QSOs.
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `brandmeister_sessions` (
  `id`                INT           AUTO_INCREMENT PRIMARY KEY,
  `user_id`           INT           NOT NULL,

  -- Brandmeister-assigned UUID for the transmission session
  `session_id`        VARCHAR(64)   DEFAULT NULL,

  -- Transmitting station
  `source_id`         INT           DEFAULT NULL,
  `source_call`       VARCHAR(32)   DEFAULT NULL,
  `source_name`       VARCHAR(128)  DEFAULT NULL,

  -- Destination talkgroup or private call target
  `destination_id`    INT           DEFAULT NULL,
  `destination_name`  VARCHAR(128)  DEFAULT NULL,

  -- DMR timeslot (1 or 2)
  `slot`              TINYINT       DEFAULT NULL,

  -- Repeater / hotspot callsign relaying the transmission
  `link_call`         VARCHAR(32)   DEFAULT NULL,

  -- Transmission timing
  `start_time`        DATETIME      DEFAULT NULL,
  `stop_time`         DATETIME      DEFAULT NULL,
  `duration`          FLOAT         DEFAULT NULL,

  -- RF quality metrics
  `ber`               FLOAT         DEFAULT NULL,
  `rssi`              INT           DEFAULT NULL,
  `loss`              FLOAT         DEFAULT NULL,

  -- Whether this session was logged as a QSO in WaveLog
  `logged`            TINYINT(1)    DEFAULT 0,

  -- If logged, the WaveLog QSO record ID for cross-reference
  `wavelog_qso_id`    INT           DEFAULT NULL,

  `created_at`        DATETIME      DEFAULT CURRENT_TIMESTAMP,

  -- Indexes for common query patterns
  INDEX `idx_user_time`   (`user_id`, `start_time`),
  INDEX `idx_session`     (`session_id`),
  INDEX `idx_source_call` (`source_call`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
