/**
 * ============================================================================
 * WaveLog Brandmeister DMR Plugin — Frontend JavaScript
 * ============================================================================
 *
 * Manages the client-side Socket.IO connection to Brandmeister's Last Heard
 * feed, real-time session tracking, QSO candidate building, and all AJAX
 * interactions with the WaveLog Brandmeister controller.
 *
 * Dependencies:
 *   - Socket.IO Client v4.x (loaded via CDN in the view)
 *   - jQuery (already loaded by WaveLog)
 *   - Bootstrap 5 (already loaded by WaveLog)
 *
 * @package     WaveLog
 * @subpackage  Brandmeister
 * @author      WaveLog Brandmeister Plugin
 * @license     MIT
 */

// ============================================================================
//  BRANDMEISTER PLUGIN NAMESPACE
// ============================================================================

const BM = (function() {
    'use strict';

    // -----------------------------------------------------------------------
    //  STATE
    // -----------------------------------------------------------------------

    /** @type {Object|null} Socket.IO client instance */
    let socket = null;

    /** @type {boolean} Whether we are currently connected */
    let connected = false;

    /** @type {Object} Map of active sessions keyed by SessionID */
    const activeSessions = {};

    /** @type {Array} List of completed sessions ready for QSO logging */
    let qsoCandidates = [];

    /** @type {Set} Currently subscribed channel names */
    const subscriptions = new Set();

    /** @type {number} Total events received counter */
    let eventCount = 0;

    /** @type {number} Maximum rows to show in the live feed table */
    const MAX_FEED_ROWS = 100;

    /** @type {Object|null} User configuration loaded from the server */
    let config = null;

    /** @type {number} Reconnection attempt counter for exponential backoff */
    let reconnectAttempts = 0;

    /** @type {number} Maximum reconnection delay in milliseconds */
    const MAX_RECONNECT_DELAY = 30000;

    /** @type {Object} Local cache for RadioID lookups to avoid repeated AJAX */
    const radioIdCache = {};

    // -----------------------------------------------------------------------
    //  CONFIGURATION
    // -----------------------------------------------------------------------

    /** @type {string} WaveLog base URL (set from hidden input in the view) */
    const BASE_URL = (document.getElementById('bm_base_url')?.value || '').replace(/\/$/, '');

    /** @type {string} Brandmeister Socket.IO server URL */
    const BM_SOCKET_URL = 'https://api.brandmeister.network';

    /** @type {string} Brandmeister Socket.IO path */
    const BM_SOCKET_PATH = '/lh/socket.io';

    // -----------------------------------------------------------------------
    //  INITIALISATION
    // -----------------------------------------------------------------------

    /**
     * Initialises the plugin on page load.
     * Loads saved config and auto-connects if talkgroups/repeaters are configured.
     */
    function init() {
        // Load config from the hidden input (server-rendered JSON)
        const configEl = document.getElementById('bm_config_json');
        if (configEl && configEl.value) {
            try {
                config = JSON.parse(configEl.value);
            } catch (e) {
                console.warn('[BM] Failed to parse config JSON:', e);
            }
        }

        // If config has default subscriptions, auto-connect
        if (config) {
            const hasTGs = config.monitored_talkgroups && config.monitored_talkgroups.length > 0;
            const hasRPTs = config.monitored_repeaters && config.monitored_repeaters.length > 0;
            const hasHotspot = config.hotspot_id;

            if (hasTGs || hasRPTs || hasHotspot) {
                connect();
            }
        }

        // Load session history when the History tab is shown
        document.getElementById('bm-tab-history')?.addEventListener('shown.bs.tab', function() {
            loadHistory();
        });

        // Load device info when the Hotspot tab is shown
        document.getElementById('bm-tab-hotspot')?.addEventListener('shown.bs.tab', function() {
            refreshDeviceInfo();
        });
    }

    // -----------------------------------------------------------------------
    //  SOCKET.IO CONNECTION MANAGEMENT
    // -----------------------------------------------------------------------

    /**
     * Connects to the Brandmeister Last Heard Socket.IO server.
     */
    function connect() {
        // Prevent duplicate connections
        if (socket && connected) {
            showToast('Already connected to Brandmeister', 'warning');
            return;
        }

        // Check that Socket.IO client library is loaded
        if (typeof io === 'undefined') {
            showToast('Socket.IO client library not loaded. Please refresh the page.', 'danger');
            console.error('[BM] Socket.IO client (io) is not defined. Check CDN script tag.');
            return;
        }

        updateConnectionStatus('connecting');

        try {
            socket = io(BM_SOCKET_URL, {
                path: BM_SOCKET_PATH,
                transports: ['websocket'],
                reconnection: false, // We handle reconnection manually with backoff
                timeout: 10000,
            });

            // ---- Socket.IO Event Handlers ----

            socket.on('connect', function() {
                connected = true;
                reconnectAttempts = 0;
                updateConnectionStatus('connected');
                showToast('Connected to Brandmeister Last Heard feed', 'success');

                // Subscribe to default channels from config
                autoSubscribe();
            });

            socket.on('disconnect', function(reason) {
                connected = false;
                updateConnectionStatus('disconnected');
                console.warn('[BM] Disconnected:', reason);

                // Attempt reconnection with exponential backoff
                if (reason !== 'io client disconnect') {
                    scheduleReconnect();
                }
            });

            socket.on('connect_error', function(error) {
                connected = false;
                updateConnectionStatus('error');
                console.error('[BM] Connection error:', error.message);

                // Attempt reconnection
                scheduleReconnect();
            });

            // ---- Main Data Event ----
            // Brandmeister sends session events on the 'mqtt' channel
            socket.on('mqtt', handleSessionEvent);

        } catch (error) {
            console.error('[BM] Failed to create Socket.IO connection:', error);
            updateConnectionStatus('error');
            showToast('Failed to connect: ' + error.message, 'danger');
        }
    }

    /**
     * Disconnects from the Brandmeister Socket.IO server.
     */
    function disconnect() {
        if (socket) {
            socket.disconnect();
            socket = null;
        }
        connected = false;
        subscriptions.clear();
        updateConnectionStatus('disconnected');
        renderSubscriptions();
        showToast('Disconnected from Brandmeister', 'info');
    }

    /**
     * Schedules a reconnection attempt with exponential backoff.
     */
    function scheduleReconnect() {
        reconnectAttempts++;
        const delay = Math.min(1000 * Math.pow(2, reconnectAttempts), MAX_RECONNECT_DELAY);
        console.log(`[BM] Reconnecting in ${delay}ms (attempt ${reconnectAttempts})...`);

        setTimeout(function() {
            if (!connected) {
                // Clean up old socket
                if (socket) {
                    socket.removeAllListeners();
                    socket = null;
                }
                connect();
            }
        }, delay);
    }

    // -----------------------------------------------------------------------
    //  SUBSCRIPTION MANAGEMENT
    // -----------------------------------------------------------------------

    /**
     * Auto-subscribes to channels from the saved configuration.
     */
    function autoSubscribe() {
        if (!config) return;

        // Subscribe to configured talkgroups
        if (config.monitored_talkgroups && Array.isArray(config.monitored_talkgroups)) {
            config.monitored_talkgroups.forEach(function(tg) {
                joinChannel('dst_' + tg);
            });
        }

        // Subscribe to configured repeaters
        if (config.monitored_repeaters && Array.isArray(config.monitored_repeaters)) {
            config.monitored_repeaters.forEach(function(rpt) {
                joinChannel('con_' + rpt);
            });
        }

        // Subscribe to user's hotspot if configured
        if (config.hotspot_id) {
            joinChannel('con_' + config.hotspot_id);
        }
    }

    /**
     * Joins a Socket.IO subscription channel.
     *
     * @param {string} channel  Channel name (e.g. 'dst_91', 'con_2042076')
     */
    function joinChannel(channel) {
        if (!socket || !connected) {
            showToast('Not connected. Please connect first.', 'warning');
            return;
        }

        if (subscriptions.has(channel)) {
            return; // Already subscribed
        }

        socket.emit('join', channel);
        subscriptions.add(channel);
        renderSubscriptions();
        console.log('[BM] Subscribed to:', channel);
    }

    /**
     * Leaves a Socket.IO subscription channel.
     *
     * @param {string} channel  Channel name to unsubscribe from
     */
    function leaveChannel(channel) {
        if (socket && connected) {
            socket.emit('leave', channel);
        }
        subscriptions.delete(channel);
        renderSubscriptions();
        console.log('[BM] Unsubscribed from:', channel);
    }

    /**
     * Subscribes to a talkgroup entered in the UI input field.
     */
    function subscribeTG() {
        const input = document.getElementById('bm-subscribe-tg');
        const tg = parseInt(input.value.trim());

        if (!tg || tg < 1) {
            showToast('Please enter a valid talkgroup ID', 'warning');
            return;
        }

        joinChannel('dst_' + tg);
        input.value = '';
    }

    /**
     * Subscribes to a repeater/hotspot entered in the UI input field.
     */
    function subscribeRPT() {
        const input = document.getElementById('bm-subscribe-rpt');
        const rpt = input.value.trim();

        if (!rpt) {
            showToast('Please enter a valid repeater/hotspot ID', 'warning');
            return;
        }

        joinChannel('con_' + rpt);
        input.value = '';
    }

    // -----------------------------------------------------------------------
    //  SESSION EVENT HANDLING
    // -----------------------------------------------------------------------

    /**
     * Handles incoming session events from the Brandmeister Socket.IO feed.
     *
     * Events can be:
     *   - 'Session-Start'  → A new transmission has begun
     *   - 'Session-Update' → A transmission is ongoing (periodic heartbeat)
     *   - 'Session-Stop'   → A transmission has ended
     *
     * @param {string|Object} data  The event payload (JSON string or object)
     */
    function handleSessionEvent(data) {
        // Parse the event data
        let event;
        try {
            event = (typeof data === 'string') ? JSON.parse(data) : data;
        } catch (e) {
            console.warn('[BM] Failed to parse event:', e);
            return;
        }

        eventCount++;
        document.getElementById('bm-event-count').textContent = eventCount;

        const eventType = event.Event || '';
        const sessionId = event.SessionID || '';

        switch (eventType) {
            case 'Session-Start':
                // Track the new active session
                activeSessions[sessionId] = {
                    ...event,
                    _startTime: Date.now(),
                    _active: true,
                };
                renderFeedRow(event, true);
                updateSessionCount();
                break;

            case 'Session-Update':
                // Update existing session data
                if (activeSessions[sessionId]) {
                    Object.assign(activeSessions[sessionId], event);
                }
                // Update the feed row in-place if it exists
                updateFeedRow(event);
                break;

            case 'Session-Stop':
                // Mark session as completed
                if (activeSessions[sessionId]) {
                    Object.assign(activeSessions[sessionId], event);
                    activeSessions[sessionId]._active = false;
                }
                // Update feed row and process as potential QSO candidate
                updateFeedRow(event, false);
                processCompletedSession(event);
                delete activeSessions[sessionId];
                updateSessionCount();
                break;

            default:
                // Unknown event type — still display in the feed
                renderFeedRow(event, false);
        }
    }

    /**
     * Processes a completed session to determine if it qualifies as a QSO candidate.
     *
     * @param {Object} event  The Session-Stop event data
     */
    function processCompletedSession(event) {
        const duration = event.Duration || 0;
        const minDuration = config?.min_qso_duration || 3;
        const sourceCall = event.SourceCall || '';

        // Filter out short transmissions (kerchunks) and missing callsigns
        if (duration < minDuration || !sourceCall) {
            return;
        }

        // Filter out the operator's own transmissions (don't log yourself)
        if (config?.dmr_id && String(event.SourceID) === String(config.dmr_id)) {
            return;
        }

        // Save the session to the server-side cache
        saveSessionToServer(event);

        // Check if auto-logging is enabled
        if (config?.auto_log_enabled) {
            logQSO(event);
            return;
        }

        // Add to QSO candidates for manual review
        qsoCandidates.push(event);
        renderCandidates();
        updateCandidateBadge();

        showToast(`QSO candidate: ${sourceCall} on TG ${event.DestinationID}`, 'info');
    }

    // -----------------------------------------------------------------------
    //  FEED TABLE RENDERING
    // -----------------------------------------------------------------------

    /**
     * Renders a new row in the live Last Heard table.
     *
     * @param {Object}  event   Session event data
     * @param {boolean} active  Whether the session is currently active (transmitting)
     */
    function renderFeedRow(event, active) {
        const tbody = document.getElementById('bm-lastheard-body');

        // Remove the "empty" placeholder row
        const emptyRow = document.getElementById('bm-lastheard-empty');
        if (emptyRow) emptyRow.remove();

        // Create the new row
        const tr = document.createElement('tr');
        tr.id = 'bm-row-' + (event.SessionID || Date.now());
        tr.className = active ? 'table-success' : '';

        const timeStr = event.Start
            ? new Date(event.Start * 1000).toLocaleTimeString()
            : new Date().toLocaleTimeString();

        const durationStr = event.Duration ? event.Duration.toFixed(1) + 's' : '-';
        const berStr = event.BER != null ? event.BER.toFixed(2) + '%' : '-';
        const lossStr = event.Loss != null ? event.Loss.toFixed(1) + '%' : '-';

        tr.innerHTML = `
            <td>${active ? '<span class="text-success">●</span>' : '<span class="text-muted">○</span>'}</td>
            <td><strong>${escapeHtml(event.SourceCall || '-')}</strong></td>
            <td>${escapeHtml(event.SourceName || '-')}</td>
            <td>${event.SourceID || '-'}</td>
            <td><span class="badge bg-primary">${event.DestinationID || '-'}</span>
                <small class="text-muted ms-1">${escapeHtml(event.DestinationName || '')}</small></td>
            <td>${event.Slot != null ? ('TS' + event.Slot) : '-'}</td>
            <td><small>${escapeHtml(event.LinkCall || '-')}</small></td>
            <td>${durationStr}</td>
            <td>${berStr}</td>
            <td>${lossStr}</td>
            <td><small>${timeStr}</small></td>
            <td>
                <button class="btn btn-sm btn-outline-success" title="Log QSO"
                        onclick='BM.logQSO(${JSON.stringify(event).replace(/'/g, "&#39;")})'>
                    <i class="fas fa-plus-circle"></i>
                </button>
                <button class="btn btn-sm btn-outline-info" title="Lookup"
                        onclick="BM.lookupDMRID(${event.SourceID || 0})">
                    <i class="fas fa-search"></i>
                </button>
            </td>
        `;

        // Insert at the top of the table
        tbody.insertBefore(tr, tbody.firstChild);

        // Enforce maximum row limit
        while (tbody.children.length > MAX_FEED_ROWS) {
            tbody.removeChild(tbody.lastChild);
        }
    }

    /**
     * Updates an existing feed row with new session data (e.g. duration, BER).
     *
     * @param {Object}  event   Updated session event data
     * @param {boolean} active  Whether the session is still active (default: inferred)
     */
    function updateFeedRow(event, active) {
        const row = document.getElementById('bm-row-' + event.SessionID);
        if (!row) {
            // Row not found (may have scrolled off) — create a new one
            renderFeedRow(event, active !== undefined ? active : event.Event !== 'Session-Stop');
            return;
        }

        // Determine active state from event type if not explicitly passed
        const isActive = active !== undefined ? active : event.Event !== 'Session-Stop';
        row.className = isActive ? 'table-success' : '';

        // Update specific cells
        const cells = row.cells;
        cells[0].innerHTML = isActive
            ? '<span class="text-success">●</span>'
            : '<span class="text-muted">○</span>';
        cells[7].textContent = event.Duration ? event.Duration.toFixed(1) + 's' : '-';
        cells[8].textContent = event.BER != null ? event.BER.toFixed(2) + '%' : '-';
        cells[9].textContent = event.Loss != null ? event.Loss.toFixed(1) + '%' : '-';
    }

    /**
     * Clears all rows from the live feed table.
     */
    function clearFeed() {
        const tbody = document.getElementById('bm-lastheard-body');
        tbody.innerHTML = `
            <tr id="bm-lastheard-empty">
                <td colspan="12" class="text-center text-muted py-4">
                    <i class="fas fa-satellite-dish fa-2x mb-2 d-block"></i>
                    Feed cleared. Live activity will appear here.
                </td>
            </tr>`;
        eventCount = 0;
        document.getElementById('bm-event-count').textContent = '0';
    }

    // -----------------------------------------------------------------------
    //  QSO CANDIDATE MANAGEMENT
    // -----------------------------------------------------------------------

    /**
     * Renders the QSO candidates table from the in-memory list.
     */
    function renderCandidates() {
        const tbody = document.getElementById('bm-candidates-body');
        const emptyRow = document.getElementById('bm-candidates-empty');

        if (qsoCandidates.length === 0) {
            tbody.innerHTML = `
                <tr id="bm-candidates-empty">
                    <td colspan="7" class="text-center text-muted py-4">
                        No QSO candidates yet. Sessions will appear here when transmissions complete.
                    </td>
                </tr>`;
            return;
        }

        if (emptyRow) emptyRow.remove();

        // Rebuild the table body
        tbody.innerHTML = '';
        qsoCandidates.forEach(function(event, index) {
            const tr = document.createElement('tr');
            const timeStr = event.Start
                ? new Date(event.Start * 1000).toLocaleString()
                : '-';

            tr.innerHTML = `
                <td><strong>${escapeHtml(event.SourceCall || '-')}</strong></td>
                <td>${escapeHtml(event.SourceName || '-')}</td>
                <td><span class="badge bg-primary">${event.DestinationID || '-'}</span>
                    <small class="ms-1">${escapeHtml(event.DestinationName || '')}</small></td>
                <td>TS${event.Slot || '-'}</td>
                <td>${event.Duration ? event.Duration.toFixed(1) + 's' : '-'}</td>
                <td><small>${timeStr}</small></td>
                <td>
                    <button class="btn btn-sm btn-success me-1" onclick="BM.logCandidate(${index})">
                        <i class="fas fa-check"></i> Log
                    </button>
                    <button class="btn btn-sm btn-outline-danger" onclick="BM.removeCandidate(${index})">
                        <i class="fas fa-times"></i>
                    </button>
                </td>
            `;
            tbody.appendChild(tr);
        });
    }

    /**
     * Logs a specific QSO candidate by its index in the array.
     *
     * @param {number} index  Array index of the candidate to log
     */
    function logCandidate(index) {
        if (index < 0 || index >= qsoCandidates.length) return;
        const event = qsoCandidates[index];
        logQSO(event, function() {
            qsoCandidates.splice(index, 1);
            renderCandidates();
            updateCandidateBadge();
        });
    }

    /**
     * Removes a QSO candidate without logging it.
     *
     * @param {number} index  Array index of the candidate to remove
     */
    function removeCandidate(index) {
        qsoCandidates.splice(index, 1);
        renderCandidates();
        updateCandidateBadge();
    }

    /**
     * Logs all QSO candidates sequentially.
     */
    function logAllCandidates() {
        if (qsoCandidates.length === 0) {
            showToast('No candidates to log', 'info');
            return;
        }

        // Process them one by one (reversed so splicing doesn't shift indices)
        const toLog = [...qsoCandidates];
        qsoCandidates = [];
        renderCandidates();
        updateCandidateBadge();

        let logged = 0;
        toLog.forEach(function(event) {
            logQSO(event, function() {
                logged++;
                if (logged === toLog.length) {
                    showToast(`Logged ${logged} QSO(s) successfully`, 'success');
                }
            });
        });
    }

    /**
     * Clears all QSO candidates without logging them.
     */
    function clearCandidates() {
        qsoCandidates = [];
        renderCandidates();
        updateCandidateBadge();
    }

    // -----------------------------------------------------------------------
    //  QSO LOGGING
    // -----------------------------------------------------------------------

    /**
     * Logs a Brandmeister session as a QSO via the WaveLog backend.
     *
     * @param {Object}   sessionEvent  The Brandmeister session event data
     * @param {Function} [callback]    Optional callback on success
     */
    function logQSO(sessionEvent, callback) {
        $.ajax({
            url: BASE_URL + '/index.php/brandmeister/log_qso',
            method: 'POST',
            contentType: 'application/json',
            data: JSON.stringify(sessionEvent),
            dataType: 'json',
            success: function(response) {
                if (response.success) {
                    showToast(`QSO logged: ${sessionEvent.SourceCall || 'Unknown'}`, 'success');
                    if (typeof callback === 'function') callback(response);
                } else {
                    showToast('Failed to log QSO: ' + (response.error || response.message), 'danger');
                }
            },
            error: function(xhr) {
                const msg = xhr.responseJSON?.error || xhr.responseJSON?.message || 'Server error';
                showToast('Error logging QSO: ' + msg, 'danger');
            }
        });
    }

    /**
     * Saves a completed session to the server-side cache.
     *
     * @param {Object} sessionEvent  The session event data
     */
    function saveSessionToServer(sessionEvent) {
        $.ajax({
            url: BASE_URL + '/index.php/brandmeister/save_session',
            method: 'POST',
            contentType: 'application/json',
            data: JSON.stringify(sessionEvent),
            dataType: 'json',
            success: function(response) {
                if (response.id) {
                    sessionEvent.local_db_id = response.id;
                }
            },
            error: function() {
                console.warn('[BM] Failed to save session to server cache');
            }
        });
    }

    // -----------------------------------------------------------------------
    //  DMR ID LOOKUP
    // -----------------------------------------------------------------------

    /**
     * Looks up a DMR ID via the WaveLog backend (proxied to RadioID.net).
     * Displays the result in a toast notification.
     *
     * @param {number} dmrId  7-digit DMR ID
     */
    function lookupDMRID(dmrId) {
        if (!dmrId) return;

        // Check local cache
        if (radioIdCache[dmrId]) {
            const d = radioIdCache[dmrId];
            showToast(`${d.callsign} — ${d.fname} ${d.surname}, ${d.city}, ${d.country}`, 'info');
            return;
        }

        $.ajax({
            url: BASE_URL + '/index.php/brandmeister/lookup_dmrid/' + dmrId,
            method: 'GET',
            dataType: 'json',
            success: function(response) {
                if (response.success && response.data) {
                    const d = response.data;
                    radioIdCache[dmrId] = d;
                    showToast(
                        `<strong>${d.callsign}</strong> — ${d.fname || ''} ${d.surname || ''}<br>` +
                        `${d.city || ''}, ${d.state || ''}, ${d.country || ''}`,
                        'info'
                    );
                } else {
                    showToast('DMR ID ' + dmrId + ' not found in RadioID database', 'warning');
                }
            },
            error: function() {
                showToast('Failed to look up DMR ID ' + dmrId, 'danger');
            }
        });
    }

    // -----------------------------------------------------------------------
    //  SESSION HISTORY
    // -----------------------------------------------------------------------

    /**
     * Loads the session history from the server and renders it.
     */
    function loadHistory() {
        const tbody = document.getElementById('bm-history-body');
        tbody.innerHTML = '<tr><td colspan="8" class="text-center"><i class="fas fa-spinner fa-spin"></i> Loading...</td></tr>';

        $.ajax({
            url: BASE_URL + '/index.php/brandmeister/sessions',
            method: 'GET',
            dataType: 'json',
            success: function(response) {
                if (response.success && response.data && response.data.length > 0) {
                    tbody.innerHTML = '';
                    response.data.forEach(function(s) {
                        const tr = document.createElement('tr');
                        if (s.logged) tr.className = 'table-success';

                        const timeStr = s.start_time
                            ? new Date(s.start_time).toLocaleString()
                            : '-';

                        tr.innerHTML = `
                            <td><strong>${escapeHtml(s.source_call || '-')}</strong></td>
                            <td>${escapeHtml(s.source_name || '-')}</td>
                            <td><span class="badge bg-primary">${s.destination_id || '-'}</span>
                                <small class="ms-1">${escapeHtml(s.destination_name || '')}</small></td>
                            <td>TS${s.slot || '-'}</td>
                            <td>${s.duration ? parseFloat(s.duration).toFixed(1) + 's' : '-'}</td>
                            <td>${s.ber != null ? parseFloat(s.ber).toFixed(2) + '%' : '-'}</td>
                            <td><small>${timeStr}</small></td>
                            <td>${s.logged
                                ? '<span class="badge bg-success">Logged</span>'
                                : '<span class="badge bg-secondary">Not logged</span>'}</td>
                        `;
                        tbody.appendChild(tr);
                    });
                } else {
                    tbody.innerHTML = '<tr><td colspan="8" class="text-center text-muted">No sessions found.</td></tr>';
                }
            },
            error: function() {
                tbody.innerHTML = '<tr><td colspan="8" class="text-center text-danger">Failed to load history.</td></tr>';
            }
        });
    }

    // -----------------------------------------------------------------------
    //  SETTINGS MANAGEMENT
    // -----------------------------------------------------------------------

    /**
     * Saves the settings form to the server via AJAX.
     *
     * @param {Event} event  Form submit event
     */
    function saveSettings(event) {
        if (event) event.preventDefault();

        const form = document.getElementById('bm-settings-form');
        const saveBtn = document.getElementById('bm-save-btn');
        const statusEl = document.getElementById('bm-save-status');

        // Collect form data
        const data = {
            dmr_id:               form.querySelector('#bm-dmr-id').value.trim(),
            hotspot_id:           form.querySelector('#bm-hotspot-id').value.trim(),
            bm_api_key:           form.querySelector('#bm-api-key').value.trim(),
            station_profile_id:   form.querySelector('#bm-station-profile').value,
            frequency:            form.querySelector('#bm-frequency').value.trim(),
            band:                 form.querySelector('#bm-band').value,
            default_rst_sent:     form.querySelector('#bm-rst-sent').value.trim(),
            default_rst_rcvd:     form.querySelector('#bm-rst-rcvd').value.trim(),
            min_qso_duration:     form.querySelector('#bm-min-duration').value,
            auto_log_enabled:     form.querySelector('#bm-auto-log').checked ? 1 : 0,
            monitored_talkgroups: parseCSVNumbers(form.querySelector('#bm-default-tgs').value),
            monitored_repeaters:  parseCSVNumbers(form.querySelector('#bm-default-rpts').value),
        };

        // Disable the button during save
        saveBtn.disabled = true;
        saveBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Saving...';

        $.ajax({
            url: BASE_URL + '/index.php/brandmeister/settings',
            method: 'POST',
            contentType: 'application/json',
            data: JSON.stringify(data),
            dataType: 'json',
            success: function(response) {
                saveBtn.disabled = false;
                saveBtn.innerHTML = '<i class="fas fa-save"></i> Save Settings';

                if (response.success) {
                    // Update local config
                    config = { ...config, ...data };

                    // Flash the success indicator
                    statusEl.classList.remove('d-none');
                    setTimeout(() => statusEl.classList.add('d-none'), 3000);

                    showToast('Settings saved successfully', 'success');
                } else {
                    showToast('Failed to save: ' + (response.error || response.message), 'danger');
                }
            },
            error: function() {
                saveBtn.disabled = false;
                saveBtn.innerHTML = '<i class="fas fa-save"></i> Save Settings';
                showToast('Server error while saving settings', 'danger');
            }
        });
    }

    // -----------------------------------------------------------------------
    //  HOTSPOT TALKGROUP MANAGER
    // -----------------------------------------------------------------------

    /**
     * Adds a static talkgroup to the user's hotspot.
     */
    function addStaticTG() {
        const tgId = parseInt(document.getElementById('bm-add-tg-id').value);
        const slot = parseInt(document.getElementById('bm-add-tg-slot').value);

        if (!tgId || tgId < 1) {
            showToast('Please enter a valid talkgroup ID', 'warning');
            return;
        }

        $.ajax({
            url: BASE_URL + '/index.php/brandmeister/manage_talkgroup',
            method: 'POST',
            contentType: 'application/json',
            data: JSON.stringify({
                action: 'add',
                talkgroup_id: tgId,
                slot: slot,
            }),
            dataType: 'json',
            success: function(response) {
                if (response.success) {
                    showToast(`TG ${tgId} added to TS${slot}`, 'success');
                    document.getElementById('bm-add-tg-id').value = '';
                    refreshDeviceInfo(); // Refresh the device info
                } else {
                    showToast('Failed: ' + (response.error || 'Unknown error'), 'danger');
                }
            },
            error: function(xhr) {
                const msg = xhr.responseJSON?.error || 'Server error';
                showToast('Error: ' + msg, 'danger');
            }
        });
    }

    /**
     * Removes a static talkgroup from the user's hotspot.
     *
     * @param {number} tgId  Talkgroup ID
     * @param {number} slot  Timeslot (1 or 2)
     */
    function removeStaticTG(tgId, slot) {
        if (!confirm(`Remove TG ${tgId} from TS${slot}?`)) return;

        $.ajax({
            url: BASE_URL + '/index.php/brandmeister/manage_talkgroup',
            method: 'POST',
            contentType: 'application/json',
            data: JSON.stringify({
                action: 'remove',
                talkgroup_id: tgId,
                slot: slot,
            }),
            dataType: 'json',
            success: function(response) {
                if (response.success) {
                    showToast(`TG ${tgId} removed from TS${slot}`, 'success');
                    refreshDeviceInfo();
                } else {
                    showToast('Failed: ' + (response.error || 'Unknown error'), 'danger');
                }
            },
            error: function(xhr) {
                const msg = xhr.responseJSON?.error || 'Server error';
                showToast('Error: ' + msg, 'danger');
            }
        });
    }

    /**
     * Refreshes the hotspot device info and static talkgroup list.
     */
    function refreshDeviceInfo() {
        if (!config?.hotspot_id) {
            document.getElementById('bm-device-info').innerHTML =
                '<p class="text-warning">No hotspot ID configured. Set it in Settings.</p>';
            return;
        }

        const infoDiv = document.getElementById('bm-device-info');
        infoDiv.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Loading...';

        $.ajax({
            url: BASE_URL + '/index.php/brandmeister/device_info/' + config.hotspot_id,
            method: 'GET',
            dataType: 'json',
            success: function(response) {
                if (response.success && response.data) {
                    const d = response.data;
                    infoDiv.innerHTML = `
                        <p><strong>ID:</strong> ${d.id || config.hotspot_id}</p>
                        <p><strong>Callsign:</strong> ${escapeHtml(d.callsign || '-')}</p>
                        <p><strong>City:</strong> ${escapeHtml(d.city || '-')}</p>
                        <p><strong>Status:</strong> ${d.status || '-'}</p>
                        <p><strong>Last seen:</strong> ${d.last_seen ? new Date(d.last_seen * 1000).toLocaleString() : '-'}</p>
                    `;

                    // Render static talkgroups if available
                    if (d.staticSubscriptions && Array.isArray(d.staticSubscriptions)) {
                        renderStaticTGs(d.staticSubscriptions);
                    }
                } else {
                    infoDiv.innerHTML = '<p class="text-danger">Failed to load device info.</p>';
                }
            },
            error: function() {
                infoDiv.innerHTML = '<p class="text-danger">Error connecting to Brandmeister API.</p>';
            }
        });
    }

    /**
     * Renders the static talkgroup table for the hotspot manager.
     *
     * @param {Array} tgs  Array of static talkgroup objects
     */
    function renderStaticTGs(tgs) {
        const tbody = document.getElementById('bm-static-tg-body');

        if (!tgs || tgs.length === 0) {
            tbody.innerHTML = '<tr><td colspan="4" class="text-muted text-center">No static talkgroups configured.</td></tr>';
            return;
        }

        tbody.innerHTML = '';
        tgs.forEach(function(tg) {
            const tr = document.createElement('tr');
            tr.innerHTML = `
                <td>${tg.talkgroup || tg.group || '-'}</td>
                <td>${escapeHtml(tg.name || '-')}</td>
                <td>TS${tg.slot || '-'}</td>
                <td>
                    <button class="btn btn-sm btn-outline-danger"
                            onclick="BM.removeStaticTG(${tg.talkgroup || tg.group}, ${tg.slot})">
                        <i class="fas fa-trash"></i> Remove
                    </button>
                </td>
            `;
            tbody.appendChild(tr);
        });
    }

    // -----------------------------------------------------------------------
    //  UI HELPERS
    // -----------------------------------------------------------------------

    /**
     * Updates the connection status banner.
     *
     * @param {string} status  One of: 'connected', 'disconnected', 'connecting', 'error'
     */
    function updateConnectionStatus(status) {
        const banner = document.getElementById('bm-connection-status');
        const icon = document.getElementById('bm-status-icon');
        const text = document.getElementById('bm-status-text');
        const connectBtn = document.getElementById('bm-connect-btn');
        const disconnectBtn = document.getElementById('bm-disconnect-btn');

        switch (status) {
            case 'connected':
                banner.className = 'alert alert-success d-flex align-items-center';
                icon.textContent = '⬤';
                icon.className = 'me-2 text-success';
                text.textContent = 'Connected to Brandmeister Last Heard feed';
                connectBtn.classList.add('d-none');
                disconnectBtn.classList.remove('d-none');
                break;

            case 'connecting':
                banner.className = 'alert alert-warning d-flex align-items-center';
                icon.innerHTML = '<i class="fas fa-spinner fa-spin"></i>';
                icon.className = 'me-2';
                text.textContent = 'Connecting to Brandmeister...';
                connectBtn.classList.add('d-none');
                disconnectBtn.classList.add('d-none');
                break;

            case 'error':
                banner.className = 'alert alert-danger d-flex align-items-center';
                icon.textContent = '⬤';
                icon.className = 'me-2 text-danger';
                text.textContent = 'Connection error — will retry automatically';
                connectBtn.classList.remove('d-none');
                disconnectBtn.classList.add('d-none');
                break;

            case 'disconnected':
            default:
                banner.className = 'alert alert-secondary d-flex align-items-center';
                icon.textContent = '⬤';
                icon.className = 'me-2 text-muted';
                text.textContent = 'Disconnected from Brandmeister';
                connectBtn.classList.remove('d-none');
                disconnectBtn.classList.add('d-none');
                break;
        }
    }

    /**
     * Renders the active subscription badges in the UI.
     */
    function renderSubscriptions() {
        const container = document.getElementById('bm-subscriptions');
        container.innerHTML = '';

        subscriptions.forEach(function(channel) {
            const badge = document.createElement('span');
            badge.className = 'badge bg-info text-dark d-flex align-items-center gap-1';

            // Parse channel type and ID
            let label;
            if (channel.startsWith('dst_')) {
                label = 'TG ' + channel.substring(4);
            } else if (channel.startsWith('con_')) {
                label = 'RPT ' + channel.substring(4);
            } else if (channel.startsWith('src_')) {
                label = 'SRC ' + channel.substring(4);
            } else {
                label = channel;
            }

            badge.innerHTML = `
                ${escapeHtml(label)}
                <button type="button" class="btn-close btn-close-white ms-1" style="font-size: 0.5em;"
                        onclick="BM.leaveChannel('${channel}')"></button>
            `;
            container.appendChild(badge);
        });

        if (subscriptions.size === 0 && connected) {
            container.innerHTML = '<small class="text-muted">No active subscriptions. Subscribe to a talkgroup or repeater above.</small>';
        }
    }

    /**
     * Updates the active session count badge.
     */
    function updateSessionCount() {
        const count = Object.keys(activeSessions).length;
        const el = document.getElementById('bm-session-count');
        el.textContent = count + ' active';
    }

    /**
     * Updates the QSO candidate badge count on the tab.
     */
    function updateCandidateBadge() {
        document.getElementById('bm-candidate-badge').textContent = qsoCandidates.length;
    }

    /**
     * Shows a Bootstrap toast notification.
     *
     * @param {string} message  HTML message content
     * @param {string} type     Bootstrap color: 'success', 'danger', 'warning', 'info'
     */
    function showToast(message, type) {
        const toastEl = document.getElementById('bm-toast');
        const bodyEl = document.getElementById('bm-toast-body');

        // Set color
        toastEl.className = `toast align-items-center text-white bg-${type || 'info'} border-0`;
        bodyEl.innerHTML = message;

        // Show using Bootstrap's Toast API
        const toast = new bootstrap.Toast(toastEl, { delay: 4000 });
        toast.show();
    }

    // -----------------------------------------------------------------------
    //  UTILITY FUNCTIONS
    // -----------------------------------------------------------------------

    /**
     * Escapes HTML special characters to prevent XSS.
     *
     * @param   {string} str  Raw string
     * @returns {string}       HTML-escaped string
     */
    function escapeHtml(str) {
        if (!str) return '';
        const div = document.createElement('div');
        div.textContent = str;
        return div.innerHTML;
    }

    /**
     * Parses a comma-separated string of numbers into an array of integers.
     *
     * @param   {string} str  CSV string (e.g. "91, 3100, 31012")
     * @returns {Array}        Array of integers
     */
    function parseCSVNumbers(str) {
        if (!str || !str.trim()) return [];
        return str.split(',')
            .map(s => parseInt(s.trim()))
            .filter(n => !isNaN(n) && n > 0);
    }

    // -----------------------------------------------------------------------
    //  INITIALISE ON DOM READY
    // -----------------------------------------------------------------------
    $(document).ready(init);

    // -----------------------------------------------------------------------
    //  PUBLIC API
    // -----------------------------------------------------------------------
    return {
        connect,
        disconnect,
        subscribeTG,
        subscribeRPT,
        leaveChannel,
        logQSO,
        logCandidate,
        removeCandidate,
        logAllCandidates,
        clearCandidates,
        clearFeed,
        lookupDMRID,
        saveSettings,
        addStaticTG,
        removeStaticTG,
        refreshDeviceInfo,
        loadHistory,
    };

})();
